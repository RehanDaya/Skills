#!/usr/bin/env python3
"""Extract dated V-Party measures from the public vdemdata RData package."""

from __future__ import annotations

import argparse
import json
from datetime import date
from pathlib import Path

import pandas as pd
import pyreadr


IDENTIFIERS = [
    "v2paenname", "v2paorname", "v2pashname", "v2paid", "pf_party_id",
    "country_name", "histname", "country_id", "country_text_id", "year",
    "historical_date", "v2paallian", "v2panaallian", "v2paseatshare", "v2panumbseat", "v2patotalseat",
    "v2pavote", "v2paelcont", "v2paelcont_nr", "v2pagovsup",
]

INDEXES = ["v2xpa_antiplural", "v2xpa_popul"]

EXPERT_SCALES = [
    "v2paanteli", "v2papeople", "v2paopresp", "v2paplur", "v2paminor",
    "v2paviol", "v2paimmig", "v2palgbt", "v2paculsup", "v2parelig",
    "v2pagender", "v2pawomlab", "v2pariglef", "v2pawelf", "v2paclient",
    "v2palocoff", "v2paactcom", "v2pasoctie", "v2panom", "v2padisa", "v2paind",
]

MULTISELECTS = {
    "v2pagroup": range(0, 15),
    "v2pasalie": range(0, 18),
    "v2pafunds": range(0, 8),
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rdata", required=True, type=Path, help="vparty.RData from the official vdemdata package")
    parser.add_argument("--output", required=True, type=Path, help="Output CSV path")
    parser.add_argument("--as-of", type=date.fromisoformat, default=date.today(), help="Research date (YYYY-MM-DD)")
    args = parser.parse_args()

    loaded = pyreadr.read_r(str(args.rdata))
    if "vparty" not in loaded:
        raise ValueError("RData file does not contain the expected 'vparty' data frame")
    source = loaded["vparty"].copy()

    wanted = list(IDENTIFIERS)
    for name in INDEXES:
        wanted.extend([name, f"{name}_codelow", f"{name}_codehigh"])
    for name in EXPERT_SCALES:
        wanted.extend([f"{name}_osp", f"{name}_osp_codelow", f"{name}_osp_codehigh", f"{name}_nr"])
    for name, values in MULTISELECTS.items():
        wanted.extend(f"{name}_{index}" for index in values)
        wanted.append(f"{name}_nr")
    missing = [name for name in wanted if name not in source.columns]
    if missing:
        raise ValueError(f"Expected V-Party fields are missing: {', '.join(missing)}")

    source["year"] = pd.to_numeric(source["year"], errors="coerce")
    first_year = args.as_of.year - 100
    subset = source.loc[source["year"].between(first_year, args.as_of.year), wanted].copy()
    expert_cols = [f"{name}_osp" for name in EXPERT_SCALES] + INDEXES
    subset["expert_coded_measures_available"] = subset[expert_cols].notna().any(axis=1)
    subset["measurement_source"] = "V-Party v2"
    subset["package_release"] = "vdemdata 16.0 (2026)"
    subset["research_window_start_year"] = first_year
    subset["research_as_of"] = args.as_of.isoformat()

    dates = pd.to_datetime(subset["historical_date"], unit="ms", utc=True, errors="coerce")
    subset["election_date"] = dates.dt.strftime("%Y-%m-%d")
    subset = subset.drop(columns=["historical_date"])
    for identifier in ["v2paid", "pf_party_id"]:
        subset[identifier] = subset[identifier].map(lambda value: str(int(value)) if pd.notna(value) else "")
    subset = subset.sort_values(["country_id", "v2paid", "year"], kind="stable")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    subset.to_csv(args.output, index=False, encoding="utf-8", na_rep="")

    print(json.dumps({
        "as_of": args.as_of.isoformat(),
        "window_start_year": first_year,
        "window_end_year": args.as_of.year,
        "party_election_rows": int(len(subset)),
        "unique_parties": int(subset["v2paid"].nunique()),
        "country_units": int(subset["country_id"].nunique()),
        "rows_with_expert_coded_measures": int(subset["expert_coded_measures_available"].sum()),
        "expert_measure_year_min": int(subset.loc[subset["expert_coded_measures_available"], "year"].min()),
        "expert_measure_year_max": int(subset.loc[subset["expert_coded_measures_available"], "year"].max()),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
