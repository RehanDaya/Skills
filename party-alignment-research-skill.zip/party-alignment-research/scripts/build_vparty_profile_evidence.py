#!/usr/bin/env python3
"""Build a long-form, source-linked evidence table from selected V-Party fields."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


CODEBOOK_URL = "https://v-dem.net/documents/6/vparty_codebook_v2.pdf"

# Each mapping preserves the codebook's meaning. These values are evidence for
# dated observations, not complete narrative profiles or timeless party labels.
INDICATORS = [
    {
        "field": "v2paimmig_osp", "low": "v2paimmig_osp_codelow", "high": "v2paimmig_osp_codehigh", "nr": "v2paimmig_nr",
        "dimension": "policy", "topic": "immigration", "name": "Immigration position", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate stronger support for most or all forms of immigration.",
        "limitation": "This is a pre-election position estimate. It does not specify every migration category or policy instrument.",
    },
    {
        "field": "v2palgbt_osp", "low": "v2palgbt_osp_codelow", "high": "v2palgbt_osp_codehigh", "nr": "v2palgbt_nr",
        "dimension": "policy", "topic": "LGBT social equality", "name": "LGBT social equality", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate stronger support for LGBT social equality.",
        "limitation": "This does not describe every legal or social equality policy.",
    },
    {
        "field": "v2pawomlab_osp", "low": "v2pawomlab_osp_codelow", "high": "v2pawomlab_osp_codehigh", "nr": "v2pawomlab_nr",
        "dimension": "policy", "topic": "women's labor-market equality", "name": "Women's equal participation in the labor market", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate stronger support for equal participation, including measures such as equal treatment and pay, parental leave, and childcare support.",
        "limitation": "This is narrower than a general measure of gender equality.",
    },
    {
        "field": "v2pariglef_osp", "low": "v2pariglef_osp_codelow", "high": "v2pariglef_osp_codehigh", "nr": "v2pariglef_nr",
        "dimension": "policy", "topic": "economic organization", "name": "Economic left-right position", "minimum": 0, "maximum": 6,
        "interpretation": "0 is far-left and 6 is far-right. The codebook relates this scale to the preferred economic role of government, including taxes, regulation, spending, and welfare.",
        "limitation": "This is a broad expert-coded summary, not a detailed position on any single economic policy.",
    },
    {
        "field": "v2pawelf_osp", "low": "v2pawelf_osp_codelow", "high": "v2pawelf_osp_codehigh", "nr": "v2pawelf_nr",
        "dimension": "policy", "topic": "welfare", "name": "Means-tested and universal welfare", "minimum": 0, "maximum": 5,
        "interpretation": "0 indicates opposition to public welfare. Higher values indicate a greater emphasis on universalistic rather than means-tested welfare, up to 5 for universal policies.",
        "limitation": "The categories distinguish welfare-policy emphasis. They do not specify benefit levels, eligibility details, or financing.",
    },
    {
        "field": "v2xpa_antiplural", "low": "v2xpa_antiplural_codelow", "high": "v2xpa_antiplural_codehigh", "nr": "",
        "dimension": "political_culture", "topic": "democratic pluralism", "name": "Anti-pluralism index", "minimum": 0, "maximum": 1,
        "scale_type": "derived interval index",
        "interval_definition": "68% highest posterior density interval on the index scale",
        "interpretation": "Higher values indicate a weaker commitment to democratic norms. The index combines expert measures of opponent treatment, political pluralism, minority rights, and rejection of political violence.",
        "limitation": "This is a derived index, not a coder-counted item in this extract. Its components are also listed separately where available. Review component uncertainty and codebook cautions.",
    },
    {
        "field": "v2xpa_popul", "low": "v2xpa_popul_codelow", "high": "v2xpa_popul_codehigh", "nr": "",
        "dimension": "political_culture", "topic": "populist rhetoric", "name": "Populism index", "minimum": 0, "maximum": 1,
        "scale_type": "derived interval index",
        "interval_definition": "68% highest posterior density interval on the index scale",
        "interpretation": "Higher values indicate more narrowly defined populist rhetoric, combining anti-elite rhetoric and people-centrism.",
        "limitation": "This is a derived rhetoric index, not a full description of a party's ideology or policy program.",
    },
    {
        "field": "v2paanteli_osp", "low": "v2paanteli_osp_codelow", "high": "v2paanteli_osp_codehigh", "nr": "v2paanteli_nr",
        "dimension": "political_culture", "topic": "political rhetoric", "name": "Anti-elite rhetoric", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate that anti-elite statements are more important and frequent in party leadership rhetoric.",
        "limitation": "The groups described as elites can vary by country and party.",
    },
    {
        "field": "v2papeople_osp", "low": "v2papeople_osp_codelow", "high": "v2papeople_osp_codehigh", "nr": "v2papeople_nr",
        "dimension": "political_culture", "topic": "political rhetoric", "name": "People-centrism", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate more frequent leadership rhetoric that glorifies ordinary people and claims to represent a unified people.",
        "limitation": "This measures rhetoric and representation claims, not popular support or policy outcomes.",
    },
    {
        "field": "v2paopresp_osp", "low": "v2paopresp_osp_codelow", "high": "v2paopresp_osp_codehigh", "nr": "v2paopresp_nr",
        "dimension": "political_culture", "topic": "treatment of opponents", "name": "Severe attacks on political opponents", "minimum": 0, "maximum": 4,
        "interpretation": "Lower values indicate more frequent severe personal attacks or demonization. Higher values indicate fewer such attacks.",
        "limitation": "This covers leader rhetoric before elections. It does not establish members' or supporters' conduct.",
    },
    {
        "field": "v2paplur_osp", "low": "v2paplur_osp_codelow", "high": "v2paplur_osp_codehigh", "nr": "v2paplur_nr",
        "dimension": "political_culture", "topic": "democratic pluralism", "name": "Commitment to political pluralism", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate a stronger commitment to free and fair multiparty elections and freedoms of speech, media, assembly, and association.",
        "limitation": "The codebook reports expert disagreement for this indicator in some cases. Retain uncertainty bounds and coder counts.",
    },
    {
        "field": "v2paminor_osp", "low": "v2paminor_osp_codelow", "high": "v2paminor_osp_codehigh", "nr": "v2paminor_nr",
        "dimension": "political_culture", "topic": "minority rights", "name": "Majority rule and minority rights", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate stronger rejection of implementing majority preferences when they violate minority rights.",
        "limitation": "This is an expert assessment of expressed leadership positions, not a full rights record.",
    },
    {
        "field": "v2paviol_osp", "low": "v2paviol_osp_codelow", "high": "v2paviol_osp_codehigh", "nr": "v2paviol_nr",
        "dimension": "political_culture", "topic": "political violence", "name": "Rejection of violence against domestic opponents", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate stronger and more consistent leadership discouragement of violence against domestic political opponents.",
        "limitation": "The measure excludes opponents engaged in armed conflict with the state and does not establish actual conduct by party members or supporters.",
    },
    {
        "field": "v2paculsup_osp", "low": "v2paculsup_osp_codelow", "high": "v2paculsup_osp_codehigh", "nr": "v2paculsup_nr",
        "dimension": "political_culture", "topic": "political identity rhetoric", "name": "Cultural superiority rhetoric", "minimum": 0, "maximum": 4,
        "interpretation": "Lower values indicate stronger promotion of the cultural superiority of a social group or nation. Higher values indicate stronger opposition to such claims.",
        "limitation": "The indicator concerns national or other social-group identities and excludes gender and sexual-orientation groups.",
    },
    {
        "field": "v2parelig_osp", "low": "v2parelig_osp_codelow", "high": "v2parelig_osp_codehigh", "nr": "v2parelig_nr",
        "dimension": "political_culture", "topic": "religious rhetoric", "name": "Use of religious principles in political justification", "minimum": 0, "maximum": 4,
        "interpretation": "Lower values indicate more frequent use of God, religion, or sacred texts to justify party positions. Higher values indicate less frequent use.",
        "limitation": "This measures rhetorical justification, not the party's complete relationship to religion or the state.",
    },
    {
        "field": "v2pagender_osp", "low": "v2pagender_osp_codelow", "high": "v2pagender_osp_codehigh", "nr": "v2pagender_nr",
        "dimension": "political_culture", "topic": "internal representation", "name": "Women in national-level party leadership", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate a greater share of women in national-level party leadership. The top category represents about 40% or more.",
        "limitation": "The measure concerns party leadership, not women's share of legislators or supporters.",
    },
    {
        "field": "v2paclient_osp", "low": "v2paclient_osp_codelow", "high": "v2paclient_osp_codehigh", "nr": "v2paclient_nr",
        "dimension": "political_culture", "topic": "campaign practice", "name": "Clientelistic campaign benefits", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate greater use of targeted, excludable goods or benefits to keep or gain votes.",
        "limitation": "The codebook distinguishes targeted vote-seeking benefits from customary small gifts. Verify context before describing conduct.",
    },
    {
        "field": "v2palocoff_osp", "low": "v2palocoff_osp_codelow", "high": "v2palocoff_osp_codehigh", "nr": "v2palocoff_nr",
        "dimension": "political_culture", "topic": "party organization", "name": "Permanent local party offices", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate permanent local offices in a larger share of municipalities outside campaign periods.",
        "limitation": "This measures organizational presence, not member participation or organizational independence.",
    },
    {
        "field": "v2paactcom_osp", "low": "v2paactcom_osp_codelow", "high": "v2paactcom_osp_codehigh", "nr": "v2paactcom_nr",
        "dimension": "political_culture", "topic": "party organization", "name": "Permanent local party activity", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate more widespread permanent local activity by party activists and personnel.",
        "limitation": "This measures presence and activity, not the openness or autonomy of local organizations.",
    },
    {
        "field": "v2pasoctie_osp", "low": "v2pasoctie_osp_codelow", "high": "v2pasoctie_osp_codehigh", "nr": "v2pasoctie_nr",
        "dimension": "political_culture", "topic": "party organization", "name": "Ties to social organizations", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate stronger ties to prominent social organizations, with 4 indicating party control of such organizations.",
        "limitation": "Organizations can include unions, religious, cultural, political, professional, and business groups. The codebook excludes militias and paramilitary units.",
    },
    {
        "field": "v2panom_osp", "low": "v2panom_osp_codelow", "high": "v2panom_osp_codehigh", "nr": "v2panom_nr",
        "dimension": "political_culture", "topic": "candidate selection", "name": "Candidate nomination process", "minimum": 0, "maximum": 4,
        "interpretation": "Categories move from unilateral party-leader selection (0), through party leadership and local delegates (1–2), to party-member primaries (3) and registered-voter primaries (4).",
        "limitation": "The ordinal categories describe the most common national legislative nomination practice. They do not measure the fairness or competitiveness of each process.",
    },
    {
        "field": "v2padisa_osp", "low": "v2padisa_osp_codelow", "high": "v2padisa_osp_codehigh", "nr": "v2padisa_nr",
        "dimension": "political_culture", "topic": "internal dissent", "name": "Visible disagreement among party elites", "minimum": 0, "maximum": 4,
        "interpretation": "Lower values indicate more visible strategic disagreement and, at the lowest levels, departures. Higher values indicate less visible disagreement.",
        "limitation": "Less visible disagreement does not prove unity or healthy internal democracy. The codebook covers prominent party elites and strategy disputes.",
    },
    {
        "field": "v2paind_osp", "low": "v2paind_osp_codelow", "high": "v2paind_osp_codehigh", "nr": "v2paind_nr",
        "dimension": "political_culture", "topic": "leadership concentration", "name": "Personalization around one leader", "minimum": 0, "maximum": 4,
        "interpretation": "Higher values indicate that the party is more focused on one leader's personal will and priorities.",
        "limitation": "This does not alone establish leader selection rules or the actual power of internal bodies.",
    },
]

for _indicator in INDICATORS:
    _indicator.setdefault("scale_type", "linearized estimate on the original ordinal scale")
    _indicator.setdefault("interval_definition", "70% highest posterior density interval on the original ordinal scale")


def parse_number(value: str | None) -> float | None:
    if value is None or value.strip() in {"", "NA", "NaN", "nan", "."}:
        return None
    try:
        return float(value)
    except ValueError:
        return None


def display_number(value: float | None) -> str:
    if value is None:
        return ""
    return str(int(value)) if value.is_integer() else str(value)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--dictionary-output", required=True, type=Path)
    parser.add_argument("--crosswalk-audit", required=True, type=Path)
    args = parser.parse_args()

    columns = [
        "v2paid", "raw_pf_party_id", "partyfacts_id", "partyfacts_crosswalk_status", "partyfacts_crosswalk_needs_review",
        "party_name_english", "party_name_original", "party_name_short", "party_alliance_code", "pre_electoral_alliance_name", "country_name",
        "histname", "country_text_id", "year", "election_date", "indicator_code",
        "estimate", "uncertainty_low", "uncertainty_high", "coder_count",
        "point_estimate_use",
    ]

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.dictionary_output.parent.mkdir(parents=True, exist_ok=True)
    with args.crosswalk_audit.open(newline="", encoding="utf-8-sig") as audit_file:
        crosswalk_by_vparty_id = {row["v2paid"]: row for row in csv.DictReader(audit_file)}
    dictionary_columns = [
        "indicator_code", "dimension", "topic", "indicator_name", "scale_min", "scale_max", "scale_type", "interval_definition",
        "interpretation", "limitations", "source_title", "source_url",
    ]
    with args.dictionary_output.open("w", newline="", encoding="utf-8") as dictionary_file:
        dictionary_writer = csv.DictWriter(dictionary_file, fieldnames=dictionary_columns)
        dictionary_writer.writeheader()
        for indicator in INDICATORS:
            dictionary_writer.writerow({
                "indicator_code": indicator["field"],
                "dimension": indicator["dimension"],
                "topic": indicator["topic"],
                "indicator_name": indicator["name"],
                "scale_min": indicator["minimum"],
                "scale_max": indicator["maximum"],
                "scale_type": indicator["scale_type"],
                "interval_definition": indicator["interval_definition"],
                "interpretation": indicator["interpretation"],
                "limitations": indicator["limitation"],
                "source_title": "V-Party Codebook v2 / V-Dem vdemdata package 16.0",
                "source_url": CODEBOOK_URL,
            })

    count = 0
    observations = 0
    with args.input.open(newline="", encoding="utf-8-sig") as input_file, args.output.open("w", newline="", encoding="utf-8") as output_file:
        reader = csv.DictReader(input_file)
        writer = csv.DictWriter(output_file, fieldnames=columns)
        writer.writeheader()
        for record in reader:
            observations += 1
            for indicator in INDICATORS:
                estimate = parse_number(record.get(indicator["field"]))
                if estimate is None:
                    continue
                low = parse_number(record.get(indicator["low"]))
                high = parse_number(record.get(indicator["high"]))
                coder_count = parse_number(record.get(indicator["nr"])) if indicator["nr"] else None
                crosswalk = crosswalk_by_vparty_id.get(record.get("v2paid", ""), {})
                if coder_count is None:
                    use_status = "derived_index_coder_count_unavailable_check_components"
                elif coder_count <= 3:
                    use_status = "do_not_interpret_point_estimate_three_or_fewer_ratings"
                elif coder_count < 5:
                    use_status = "below_five_coder_target_use_with_caution"
                else:
                    use_status = "eligible_with_uncertainty_and_context"
                writer.writerow({
                    "v2paid": record.get("v2paid", ""),
                    "raw_pf_party_id": record.get("pf_party_id", ""),
                    "partyfacts_id": crosswalk.get("candidate_join_partyfacts_id", ""),
                    "partyfacts_crosswalk_status": crosswalk.get("crosswalk_status", "audit_row_missing"),
                    "partyfacts_crosswalk_needs_review": crosswalk.get("needs_review", "true"),
                    "party_name_english": record.get("v2paenname", ""),
                    "party_name_original": record.get("v2paorname", ""),
                    "party_name_short": record.get("v2pashname", ""),
                    "party_alliance_code": record.get("v2paallian", ""),
                    "pre_electoral_alliance_name": record.get("v2panaallian", ""),
                    "country_name": record.get("country_name", ""),
                    "histname": record.get("histname", ""),
                    "country_text_id": record.get("country_text_id", ""),
                    "year": record.get("year", ""),
                    "election_date": record.get("election_date", ""),
                    "indicator_code": indicator["field"],
                    "estimate": display_number(estimate),
                    "uncertainty_low": display_number(low),
                    "uncertainty_high": display_number(high),
                    "coder_count": display_number(coder_count),
                    "point_estimate_use": use_status,
                })
                count += 1

    print({
        "party_election_rows_read": observations,
        "evidence_rows_written": count,
        "indicator_definitions_written": len(INDICATORS),
        "output": str(args.output),
        "dictionary_output": str(args.dictionary_output),
    })


if __name__ == "__main__":
    main()
