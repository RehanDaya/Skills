#!/usr/bin/env python3
"""Build a rolling-period party candidate directory from Party Facts and V-Party data."""

from __future__ import annotations

import argparse
import csv
import gzip
import json
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def year_value(value: str | None) -> int | None:
    if not value:
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def id_value(value: str | None) -> str:
    if not value:
        return ""
    value = value.strip()
    try:
        number = float(value)
        if number.is_integer():
            return str(int(number))
    except ValueError:
        pass
    return value


def write_csv(path: Path, rows: list[dict[str, object]], columns: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--core", required=True, type=Path, help="Party Facts core-parties CSV")
    parser.add_argument("--external", required=True, type=Path, help="Party Facts external-parties CSV")
    parser.add_argument("--countries", required=True, type=Path, help="Party Facts countries CSV")
    parser.add_argument("--m49", required=True, type=Path, help="UN M49 country-or-area CSV with ISO-alpha3 codes")
    parser.add_argument("--vparty-measures", type=Path, help="Curated V-Party measures CSV")
    parser.add_argument("--vparty-crosswalk-audit", type=Path, help="Audited V-Party to Party Facts crosswalk CSV")
    parser.add_argument("--vparty-profile-observations", type=Path, help="Optional draft profile observations JSONL or JSONL.GZ")
    parser.add_argument("--narrative-profile-drafts", type=Path, help="Optional hand-curated narrative profile drafts JSONL")
    parser.add_argument("--manifesto-register", type=Path, help="Period-filtered public Manifesto Project party register CSV")
    parser.add_argument("--output", required=True, type=Path, help="Output data directory")
    parser.add_argument("--as-of", type=date.fromisoformat, default=date.today(), help="Research date (YYYY-MM-DD)")
    args = parser.parse_args()

    end_year = args.as_of.year
    start_year = end_year - 100
    core = read_csv(args.core)
    external = read_csv(args.external)
    countries = read_csv(args.countries)
    m49 = read_csv(args.m49)
    vparty = read_csv(args.vparty_measures) if args.vparty_measures else []
    vparty_crosswalk_audit = read_csv(args.vparty_crosswalk_audit) if args.vparty_crosswalk_audit else []
    crosswalk_by_vparty_id = {row["v2paid"]: row for row in vparty_crosswalk_audit}
    manifesto = read_csv(args.manifesto_register) if args.manifesto_register else []
    draft_profiles_by_country: dict[str, Counter[str]] = defaultdict(Counter)
    if args.vparty_profile_observations:
        opener = gzip.open if args.vparty_profile_observations.name.endswith(".gz") else Path.open
        with opener(args.vparty_profile_observations, "rt", encoding="utf-8") as profile_file:
            for line in profile_file:
                profile = json.loads(line)
                country = str(profile.get("country_unit", {}).get("code") or "")
                if not country:
                    continue
                draft_profiles_by_country[country]["records"] += 1
                draft_profiles_by_country[country]["policy_items"] += len(profile.get("policy_evidence") or [])
                draft_profiles_by_country[country]["culture_items"] += len(profile.get("political_culture_evidence") or [])

    narrative_profiles_by_country: dict[str, Counter[str]] = defaultdict(Counter)
    narrative_country_names_by_country: dict[str, set[str]] = defaultdict(set)
    if args.narrative_profile_drafts:
        with args.narrative_profile_drafts.open("r", encoding="utf-8") as profile_file:
            for line in profile_file:
                if not line.strip():
                    continue
                profile = json.loads(line)
                country = str(profile.get("country_unit", {}).get("code") or "")
                if not country:
                    continue
                name = str(profile.get("country_unit", {}).get("name") or "")
                if name:
                    narrative_country_names_by_country[country].add(name)
                counts = narrative_profiles_by_country[country]
                counts["records"] += 1
                counts[str(profile.get("review_status") or "unknown")] += 1
                counts["policy_items"] += len(profile.get("policy_evidence") or [])
                counts["culture_items"] += len(profile.get("political_culture_evidence") or [])

    source_keys: dict[str, set[str]] = defaultdict(set)
    source_rows: dict[str, Counter[str]] = defaultdict(Counter)
    for row in external:
        party_id = (row.get("partyfacts_id") or "").strip()
        source = (row.get("dataset_key") or "").strip()
        if not party_id or not source:
            continue
        source_keys[party_id].add(source)
        source_rows[party_id][source] += 1

    manifesto_records_by_partyfacts: dict[str, list[dict[str, str]]] = defaultdict(list)
    manifesto_unlinked_rows: list[dict[str, str]] = []
    manifesto_ids_by_country: dict[str, set[str]] = defaultdict(set)
    manifesto_country_names_by_country: dict[str, set[str]] = defaultdict(set)
    manifesto_documents_by_country: Counter[str] = Counter()
    manifesto_unlinked_by_country: Counter[str] = Counter()
    for row in manifesto:
        manifesto_id = (row.get("manifesto_party_id") or "").strip()
        country = (row.get("country_code") or "").strip()
        linked_ids = sorted({id_value(value) for value in (row.get("partyfacts_ids") or row.get("partyfacts_id") or "").split(";") if id_value(value)})
        if country and manifesto_id:
            manifesto_ids_by_country[country].add(manifesto_id)
            manifesto_country_names_by_country[country].add((row.get("manifesto_country_name") or "").strip())
            manifesto_documents_by_country[country] += year_value(row.get("documents_in_window")) or 0
            if not linked_ids:
                manifesto_unlinked_by_country[country] += 1
        if linked_ids:
            for party_id in linked_ids:
                manifesto_records_by_partyfacts[party_id].append(row)
        else:
            manifesto_unlinked_rows.append(row)

    def manifesto_fields(party_id: str) -> dict[str, object]:
        rows = manifesto_records_by_partyfacts.get(party_id, [])
        years = [year_value(row.get(field)) for row in rows for field in ("first_document_year_in_window", "last_document_year_in_window")]
        years = [year for year in years if year is not None]
        return {
            "manifesto_party_ids": ";".join(sorted({(row.get("manifesto_party_id") or "").strip() for row in rows if (row.get("manifesto_party_id") or "").strip()})),
            "manifesto_country_codes": ";".join(sorted({(row.get("manifesto_country_code") or "").strip() for row in rows if (row.get("manifesto_country_code") or "").strip()})),
            "manifesto_document_count": sum(year_value(row.get("documents_in_window")) or 0 for row in rows),
            "manifesto_first_document_year": min(years) if years else "",
            "manifesto_last_document_year": max(years) if years else "",
        }

    vparty_years: dict[str, list[int]] = defaultdict(list)
    vparty_expert_rows: Counter[str] = Counter()
    vparty_ids_by_party: dict[str, set[str]] = defaultdict(set)
    vparty_countries_by_party: dict[str, set[str]] = defaultdict(set)
    vparty_crosswalk_statuses_by_party: dict[str, set[str]] = defaultdict(set)
    vparty_raw_partyfacts_ids_by_party: dict[str, set[str]] = defaultdict(set)
    vparty_names_by_party: dict[str, dict[str, str]] = defaultdict(dict)
    vparty_rows_by_country: Counter[str] = Counter()
    vparty_ids_by_country: dict[str, set[str]] = defaultdict(set)
    vparty_country_names: dict[str, set[str]] = defaultdict(set)
    vparty_expert_rows_by_country: Counter[str] = Counter()
    for row in vparty:
        vparty_id = id_value(row.get("v2paid"))
        audit_row = crosswalk_by_vparty_id.get(vparty_id, {})
        party_id = id_value(audit_row.get("candidate_join_partyfacts_id")) if args.vparty_crosswalk_audit else id_value(row.get("pf_party_id"))
        party_key = party_id or f"vparty:{vparty_id}"
        country = (row.get("country_text_id") or "").strip()
        year = year_value(row.get("year"))
        if party_key and year is not None:
            vparty_years[party_key].append(year)
            if audit_row.get("crosswalk_status"):
                vparty_crosswalk_statuses_by_party[party_key].add(audit_row["crosswalk_status"])
            raw_pf_id = id_value(row.get("pf_party_id"))
            if raw_pf_id:
                vparty_raw_partyfacts_ids_by_party[party_key].add(raw_pf_id)
            if vparty_id:
                vparty_ids_by_party[party_key].add(vparty_id)
            if country:
                vparty_countries_by_party[party_key].add(country)
            for field, source_field in (("party_short_name", "v2pashname"), ("party_name_original", "v2paorname"), ("party_name_english", "v2paenname")):
                value = (row.get(source_field) or "").strip()
                if value and field not in vparty_names_by_party[party_key]:
                    vparty_names_by_party[party_key][field] = value
            if (row.get("expert_coded_measures_available") or "").strip().lower() == "true":
                vparty_expert_rows[party_key] += 1
        if country:
            vparty_rows_by_country[country] += 1
            vparty_country_names[country].add((row.get("country_name") or "").strip())
            if vparty_id:
                vparty_ids_by_country[country].add(vparty_id)
            if (row.get("expert_coded_measures_available") or "").strip().lower() == "true":
                vparty_expert_rows_by_country[country] += 1

    selected: list[dict[str, object]] = []
    for row in core:
        first = year_value(row.get("year_first"))
        last = year_value(row.get("year_last"))
        if first is None or first > end_year or (last is not None and last < start_year):
            continue
        party_id = id_value(row.get("partyfacts_id"))
        keys = set(source_keys.get(party_id, set()))
        manifesto_meta = manifesto_fields(party_id)
        if manifesto_meta["manifesto_party_ids"]:
            keys.add("manifesto")
        observed_years = vparty_years.get(party_id, [])
        selected.append(
            {
                "country_code": row.get("country", ""),
                "partyfacts_id": party_id,
                "party_short_name": row.get("name_short", ""),
                "party_name_original": row.get("name", ""),
                "party_name_english": row.get("name_english", ""),
                "party_name_other": row.get("name_other", ""),
                "year_first": row.get("year_first", ""),
                "year_last": row.get("year_last", ""),
                "latest_recorded_share": row.get("share", ""),
                "share_year": row.get("share_year", ""),
                "partyfacts_description": row.get("description", ""),
                "partyfacts_wikipedia_url": row.get("wikipedia", ""),
                "source_dataset_keys": ";".join(sorted(keys)),
                "source_dataset_row_counts": json.dumps(dict(sorted(source_rows.get(party_id, {}).items())), ensure_ascii=False, separators=(",", ":")),
                "candidate_basis": "partyfacts_date_overlap",
                **manifesto_meta,
                "vparty_party_ids": ";".join(sorted(vparty_ids_by_party.get(party_id, set()))),
                "vparty_country_codes": ";".join(sorted(vparty_countries_by_party.get(party_id, set()))),
                "vparty_crosswalk_statuses": ";".join(sorted(vparty_crosswalk_statuses_by_party.get(party_id, set()))),
                "vparty_raw_partyfacts_ids": ";".join(sorted(vparty_raw_partyfacts_ids_by_party.get(party_id, set()))),
                "vparty_measurement_rows": len(observed_years),
                "vparty_expert_measurement_rows": vparty_expert_rows.get(party_id, 0),
                "vparty_first_observed_year": min(observed_years) if observed_years else "",
                "vparty_last_observed_year": max(observed_years) if observed_years else "",
                "policy_profile_status": "not_researched",
                "political_culture_profile_status": "not_researched",
                "profile_verified_at": "",
            }
        )

    selected_partyfacts_ids = {str(row["partyfacts_id"]) for row in selected}
    supplemental_keys = sorted(key for key, years in vparty_years.items() if years and (key.startswith("vparty:") or key not in selected_partyfacts_ids))
    for party_key in supplemental_keys:
        partyfacts_id = "" if party_key.startswith("vparty:") else party_key
        names = vparty_names_by_party.get(party_key, {})
        observed_years = vparty_years[party_key]
        countries_seen = sorted(vparty_countries_by_party.get(party_key, set()))
        manifesto_meta = manifesto_fields(partyfacts_id)
        supplement_sources = {"vparty"}
        if manifesto_meta["manifesto_party_ids"]:
            supplement_sources.add("manifesto")
        selected.append(
            {
                "country_code": countries_seen[0] if countries_seen else "",
                "partyfacts_id": partyfacts_id,
                "party_short_name": names.get("party_short_name", ""),
                "party_name_original": names.get("party_name_original", ""),
                "party_name_english": names.get("party_name_english", ""),
                "party_name_other": "",
                "year_first": min(observed_years),
                "year_last": max(observed_years),
                "latest_recorded_share": "",
                "share_year": "",
                "partyfacts_description": "",
                "partyfacts_wikipedia_url": "",
                "source_dataset_keys": ";".join(sorted(supplement_sources)),
                "source_dataset_row_counts": "{}",
                "candidate_basis": "vparty_observed_in_window_partyfacts_link_missing_or_dates_differ" if partyfacts_id else "vparty_observed_in_window_partyfacts_link_unavailable",
                **manifesto_meta,
                "vparty_party_ids": ";".join(sorted(vparty_ids_by_party.get(party_key, set()))),
                "vparty_country_codes": ";".join(countries_seen),
                "vparty_crosswalk_statuses": ";".join(sorted(vparty_crosswalk_statuses_by_party.get(party_key, set()))),
                "vparty_raw_partyfacts_ids": ";".join(sorted(vparty_raw_partyfacts_ids_by_party.get(party_key, set()))),
                "vparty_measurement_rows": len(observed_years),
                "vparty_expert_measurement_rows": vparty_expert_rows.get(party_key, 0),
                "vparty_first_observed_year": min(observed_years),
                "vparty_last_observed_year": max(observed_years),
                "policy_profile_status": "not_researched",
                "political_culture_profile_status": "not_researched",
                "profile_verified_at": "",
            }
        )

    selected_partyfacts_ids = {str(row["partyfacts_id"]) for row in selected if str(row["partyfacts_id"])}
    for party_id in sorted(set(manifesto_records_by_partyfacts) - selected_partyfacts_ids):
        rows = manifesto_records_by_partyfacts[party_id]
        rows.sort(key=lambda row: (str(row.get("country_code", "")), str(row.get("party_name_english", "")), str(row.get("manifesto_party_id", ""))))
        source = rows[0]
        manifesto_meta = manifesto_fields(party_id)
        selected.append(
            {
                "country_code": source.get("country_code", ""),
                "partyfacts_id": party_id,
                "party_short_name": source.get("party_abbreviation", ""),
                "party_name_original": source.get("party_name_original", ""),
                "party_name_english": source.get("party_name_english", ""),
                "party_name_other": "",
                "year_first": manifesto_meta["manifesto_first_document_year"],
                "year_last": manifesto_meta["manifesto_last_document_year"],
                "latest_recorded_share": "",
                "share_year": "",
                "partyfacts_description": "",
                "partyfacts_wikipedia_url": "",
                "source_dataset_keys": "manifesto",
                "source_dataset_row_counts": "{}",
                "candidate_basis": "manifesto_observed_in_window_partyfacts_link_missing_or_dates_differ",
                **manifesto_meta,
                "vparty_party_ids": ";".join(sorted(vparty_ids_by_party.get(party_id, set()))),
                "vparty_country_codes": ";".join(sorted(vparty_countries_by_party.get(party_id, set()))),
                "vparty_crosswalk_statuses": ";".join(sorted(vparty_crosswalk_statuses_by_party.get(party_id, set()))),
                "vparty_raw_partyfacts_ids": ";".join(sorted(vparty_raw_partyfacts_ids_by_party.get(party_id, set()))),
                "vparty_measurement_rows": len(vparty_years.get(party_id, [])),
                "vparty_expert_measurement_rows": vparty_expert_rows.get(party_id, 0),
                "vparty_first_observed_year": min(vparty_years[party_id]) if vparty_years.get(party_id) else "",
                "vparty_last_observed_year": max(vparty_years[party_id]) if vparty_years.get(party_id) else "",
                "policy_profile_status": "not_researched",
                "political_culture_profile_status": "not_researched",
                "profile_verified_at": "",
            }
        )

    existing_manifesto_ids = {
        manifesto_id
        for row in selected
        for manifesto_id in str(row.get("manifesto_party_ids", "")).split(";")
        if manifesto_id
    }
    for source in manifesto_unlinked_rows:
        manifesto_id = (source.get("manifesto_party_id") or "").strip()
        if not manifesto_id or manifesto_id in existing_manifesto_ids:
            continue
        selected.append(
            {
                "country_code": source.get("country_code", ""),
                "partyfacts_id": "",
                "party_short_name": source.get("party_abbreviation", ""),
                "party_name_original": source.get("party_name_original", ""),
                "party_name_english": source.get("party_name_english", ""),
                "party_name_other": "",
                "year_first": source.get("first_document_year_in_window", ""),
                "year_last": source.get("last_document_year_in_window", ""),
                "latest_recorded_share": "",
                "share_year": "",
                "partyfacts_description": "",
                "partyfacts_wikipedia_url": "",
                "source_dataset_keys": "manifesto",
                "source_dataset_row_counts": "{}",
                "candidate_basis": "manifesto_register_unlinked_identity",
                "manifesto_party_ids": manifesto_id,
                "manifesto_country_codes": source.get("manifesto_country_code", ""),
                "manifesto_document_count": year_value(source.get("documents_in_window")) or 0,
                "manifesto_first_document_year": source.get("first_document_year_in_window", ""),
                "manifesto_last_document_year": source.get("last_document_year_in_window", ""),
                "vparty_party_ids": "",
                "vparty_country_codes": "",
                "vparty_crosswalk_statuses": "",
                "vparty_raw_partyfacts_ids": "",
                "vparty_measurement_rows": 0,
                "vparty_expert_measurement_rows": 0,
                "vparty_first_observed_year": "",
                "vparty_last_observed_year": "",
                "policy_profile_status": "not_researched",
                "political_culture_profile_status": "not_researched",
                "profile_verified_at": "",
            }
        )
        existing_manifesto_ids.add(manifesto_id)

    selected.sort(key=lambda item: (str(item["country_code"]), str(item["party_name_english"]), str(item["partyfacts_id"])))
    counts_by_country = Counter(str(row["country_code"]) for row in selected)
    source_ids_by_country: dict[str, dict[str, set[str]]] = defaultdict(lambda: defaultdict(set))
    for row in selected:
        country = str(row["country_code"])
        party_id = str(row["partyfacts_id"])
        for source in source_keys.get(party_id, set()):
            source_ids_by_country[country][source].add(party_id)

    country_by_code = {row.get("country", ""): row for row in countries}
    coverage: list[dict[str, object]] = []
    m49_codes: set[str] = set()
    for row in sorted(m49, key=lambda item: item.get("ISO-alpha3 Code", "")):
        country = row.get("ISO-alpha3 Code", "")
        if not country:
            continue
        m49_codes.add(country)
        candidate_count = counts_by_country[country]
        partyfacts_country = country_by_code.get(country, {})
        coverage.append(
            {
                "country_code": country,
                "country_unit_name": row.get("Country or Area", ""),
                "unit_basis": "UN M49 country or area; Party Facts candidate seed present" if partyfacts_country else "UN M49 country or area; absent from Party Facts candidate seed",
                "m49_code": row.get("M49 Code", ""),
                "continent": row.get("Region Name", ""),
                "region": row.get("Sub-region Name", ""),
                "candidate_parties_in_window": candidate_count,
                "partyfacts_ids_with_vparty_mapping": len(source_ids_by_country[country].get("vparty", set())),
                "partyfacts_ids_with_manifesto_mapping": len(source_ids_by_country[country].get("manifesto", set())),
                "partyfacts_ids_with_parlgov_mapping": len(source_ids_by_country[country].get("parlgov", set())),
                "manifesto_source_party_ids": len(manifesto_ids_by_country[country]),
                "manifesto_document_records": manifesto_documents_by_country[country],
                "manifesto_party_ids_without_partyfacts_crosswalk": manifesto_unlinked_by_country[country],
                "vparty_party_ids": len(vparty_ids_by_country[country]),
                "vparty_party_election_rows": vparty_rows_by_country[country],
                "vparty_expert_measure_rows": vparty_expert_rows_by_country[country],
                "completed_policy_profiles": 0,
                "completed_culture_profiles": 0,
                "coverage_status": "candidate_seed_present" if candidate_count else ("structured_evidence_present" if vparty_ids_by_country[country] or manifesto_ids_by_country[country] else "candidate_gap_to_research"),
                "evidence_sources_present": ";".join(source for source, present in (("candidate_records", candidate_count > 0), ("vparty", bool(vparty_ids_by_country[country])), ("manifesto", bool(manifesto_ids_by_country[country]))) if present),
                "coverage_note": "Candidate records may be unmatched duplicates. Source evidence does not equal a completed party census or policy/culture profile.",
            }
        )

    for row in sorted(countries, key=lambda item: item.get("country", "")):
        country = row.get("country", "")
        if country in m49_codes:
            continue
        candidate_count = counts_by_country[country]
        coverage.append(
            {
                "country_code": country,
                "country_unit_name": row.get("name", ""),
                "unit_basis": "Party Facts-only political unit; status requires review",
                "m49_code": "",
                "continent": row.get("continent", ""),
                "region": row.get("region", ""),
                "candidate_parties_in_window": candidate_count,
                "partyfacts_ids_with_vparty_mapping": len(source_ids_by_country[country].get("vparty", set())),
                "partyfacts_ids_with_manifesto_mapping": len(source_ids_by_country[country].get("manifesto", set())),
                "partyfacts_ids_with_parlgov_mapping": len(source_ids_by_country[country].get("parlgov", set())),
                "manifesto_source_party_ids": len(manifesto_ids_by_country[country]),
                "manifesto_document_records": manifesto_documents_by_country[country],
                "manifesto_party_ids_without_partyfacts_crosswalk": manifesto_unlinked_by_country[country],
                "vparty_party_ids": len(vparty_ids_by_country[country]),
                "vparty_party_election_rows": vparty_rows_by_country[country],
                "vparty_expert_measure_rows": vparty_expert_rows_by_country[country],
                "completed_policy_profiles": 0,
                "completed_culture_profiles": 0,
                "coverage_status": "candidate_seed_present" if candidate_count else ("structured_evidence_present" if vparty_ids_by_country[country] or manifesto_ids_by_country[country] else "candidate_gap_to_research"),
                "evidence_sources_present": ";".join(source for source, present in (("candidate_records", candidate_count > 0), ("vparty", bool(vparty_ids_by_country[country])), ("manifesto", bool(manifesto_ids_by_country[country]))) if present),
                "coverage_note": "A Party Facts-only code may be historical, disputed, or another unit type. Candidate records may be unmatched duplicates. Party completeness and profiles have not been researched.",
            }
        )

    all_registered_codes = m49_codes | set(country_by_code)
    for country in sorted(set(vparty_country_names) - all_registered_codes):
        names = sorted(name for name in vparty_country_names[country] if name)
        coverage.append(
            {
                "country_code": country,
                "country_unit_name": names[0] if names else country,
                "unit_basis": "V-Party-only political unit; status review",
                "m49_code": "",
                "continent": "",
                "region": "",
                "candidate_parties_in_window": 0,
                "partyfacts_ids_with_vparty_mapping": 0,
                "partyfacts_ids_with_manifesto_mapping": 0,
                "partyfacts_ids_with_parlgov_mapping": 0,
                "manifesto_source_party_ids": len(manifesto_ids_by_country[country]),
                "manifesto_document_records": manifesto_documents_by_country[country],
                "manifesto_party_ids_without_partyfacts_crosswalk": manifesto_unlinked_by_country[country],
                "vparty_party_ids": len(vparty_ids_by_country[country]),
                "vparty_party_election_rows": vparty_rows_by_country[country],
                "vparty_expert_measure_rows": vparty_expert_rows_by_country[country],
                "completed_policy_profiles": 0,
                "completed_culture_profiles": 0,
                "coverage_status": "structured_evidence_present",
                "evidence_sources_present": "vparty",
                "coverage_note": "V-Party identifies this political unit. Verify its historical status and boundaries. Party completeness and policy/culture profiles have not been researched.",
            }
        )

    all_registered_codes.update(manifesto_country_names_by_country)
    for country in sorted(set(manifesto_country_names_by_country) - set(item["country_code"] for item in coverage)):
        names = sorted(name for name in manifesto_country_names_by_country[country] if name)
        coverage.append(
            {
                "country_code": country,
                "country_unit_name": names[0] if names else country,
                "unit_basis": "Manifesto Project-only political unit; status review",
                "m49_code": "",
                "continent": "",
                "region": "",
                "candidate_parties_in_window": counts_by_country[country],
                "partyfacts_ids_with_vparty_mapping": 0,
                "partyfacts_ids_with_manifesto_mapping": len(source_ids_by_country[country].get("manifesto", set())),
                "partyfacts_ids_with_parlgov_mapping": 0,
                "manifesto_source_party_ids": len(manifesto_ids_by_country[country]),
                "manifesto_document_records": manifesto_documents_by_country[country],
                "manifesto_party_ids_without_partyfacts_crosswalk": manifesto_unlinked_by_country[country],
                "vparty_party_ids": 0,
                "vparty_party_election_rows": 0,
                "vparty_expert_measure_rows": 0,
                "completed_policy_profiles": 0,
                "completed_culture_profiles": 0,
                "coverage_status": "candidate_seed_present" if counts_by_country[country] else "structured_evidence_present",
                "evidence_sources_present": "manifesto",
                "coverage_note": "Manifesto Project identifies this unit. Verify its political status and borders. Party completeness and policy/culture profiles have not been researched.",
            }
        )
    coverage_codes = {str(item["country_code"]) for item in coverage}
    for country in sorted(set(narrative_profiles_by_country) - coverage_codes):
        names = sorted(name for name in narrative_country_names_by_country[country] if name)
        coverage.append(
            {
                "country_code": country,
                "country_unit_name": names[0] if names else country,
                "unit_basis": "Narrative-profile-only political unit; status review",
                "m49_code": "",
                "continent": "",
                "region": "",
                "candidate_parties_in_window": 0,
                "partyfacts_ids_with_vparty_mapping": 0,
                "partyfacts_ids_with_manifesto_mapping": 0,
                "partyfacts_ids_with_parlgov_mapping": 0,
                "manifesto_source_party_ids": 0,
                "manifesto_document_records": 0,
                "manifesto_party_ids_without_partyfacts_crosswalk": 0,
                "vparty_party_ids": 0,
                "vparty_party_election_rows": 0,
                "vparty_expert_measure_rows": 0,
                "completed_policy_profiles": 0,
                "completed_culture_profiles": 0,
                "coverage_status": "candidate_gap_to_research",
                "evidence_sources_present": "narrative_profile_drafts",
                "coverage_note": "A hand-curated profile draft identifies this political unit. Verify its status, borders, party census, and profile evidence.",
            }
        )
    for item in coverage:
        country = str(item["country_code"])
        draft_counts = draft_profiles_by_country[country]
        item["vparty_draft_profile_records"] = draft_counts["records"]
        item["vparty_draft_policy_evidence_items"] = draft_counts["policy_items"]
        item["vparty_draft_culture_evidence_items"] = draft_counts["culture_items"]
        if draft_counts["records"]:
            sources = [source for source in str(item.get("evidence_sources_present", "")).split(";") if source]
            if "vparty_draft_profiles" not in sources:
                sources.append("vparty_draft_profiles")
            item["evidence_sources_present"] = ";".join(sources)
        narrative_counts = narrative_profiles_by_country[country]
        item["narrative_profile_records"] = narrative_counts["records"]
        item["narrative_profiles_draft"] = narrative_counts["draft"]
        item["narrative_profiles_reviewed"] = narrative_counts["reviewed"]
        item["narrative_profiles_verified"] = narrative_counts["verified"]
        item["narrative_profiles_stale"] = narrative_counts["stale"]
        item["narrative_policy_evidence_items"] = narrative_counts["policy_items"]
        item["narrative_culture_evidence_items"] = narrative_counts["culture_items"]
        if narrative_counts["records"]:
            sources = [source for source in str(item.get("evidence_sources_present", "")).split(";") if source]
            if "narrative_profile_drafts" not in sources:
                sources.append("narrative_profile_drafts")
            item["evidence_sources_present"] = ";".join(sources)
    coverage.sort(key=lambda item: (str(item["continent"]), str(item["region"]), str(item["country_unit_name"])))

    candidate_columns = list(selected[0].keys()) if selected else []
    coverage_columns = list(coverage[0].keys()) if coverage else []
    write_csv(args.output / "party-directory.csv", selected, candidate_columns)
    write_csv(args.output / "country-coverage.csv", coverage, coverage_columns)
    print(json.dumps({
        "as_of": args.as_of.isoformat(),
        "window_start_year": start_year,
        "window_end_year": end_year,
        "party_records": len(selected),
        "coverage_units": len(coverage),
        "party_records_with_vparty_mapping": sum("vparty" in source_keys.get(str(row["partyfacts_id"]), set()) for row in selected),
        "party_records_with_vparty_measurements": sum(bool(row["vparty_measurement_rows"]) for row in selected),
        "party_records_with_vparty_expert_measurements": sum(bool(row["vparty_expert_measurement_rows"]) for row in selected),
        "party_records_with_manifesto_mapping": sum("manifesto" in source_keys.get(str(row["partyfacts_id"]), set()) for row in selected),
        "party_records_with_manifesto_register_evidence": sum(bool(row.get("manifesto_party_ids")) for row in selected),
        "vparty_draft_profile_records": sum(value["records"] for value in draft_profiles_by_country.values()),
        "vparty_crosswalk_corrected_ids": sum(row.get("crosswalk_status") == "external_link_corrects_conflicting_raw_id" for row in vparty_crosswalk_audit),
        "vparty_crosswalk_ids_needing_review": sum(row.get("needs_review") == "true" for row in vparty_crosswalk_audit),
        "manifesto_unlinked_candidate_records": sum(str(row["candidate_basis"]) == "manifesto_register_unlinked_identity" for row in selected),
        "vparty_only_coverage_units": sum(str(row["unit_basis"]).startswith("V-Party-only") for row in coverage),
        "note": "V-Party links use the explicit Party Facts external crosswalk after checking names and country codes. Conflicting raw pf_party_id values remain in the audit file; source mappings do not prove profile completeness.",
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
