#!/usr/bin/env python3
"""Build period-filtered party and coded-document registers from the public Manifesto Project metadata."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from datetime import date
from pathlib import Path


DATASET_VERSION = "MPDS 2026a"
PARTY_LIST_URL = "https://manifestoproject.wzb.eu/down/data/2026a/codebooks/parties_MPDataset_MPDS2026a.csv"
DOCUMENT_LIST_URL = "https://manifestoproject.wzb.eu/down/data/2026a/codebooks/documents_MPDataset_MPDS2026a.csv"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]) if rows else [], extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def integer(value: str | None) -> int | None:
    if not value or value.strip().lower() in {"na", "nan", "."}:
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def clean(value: str | None) -> str:
    if value is None or value.strip().lower() in {"na", "nan", "."}:
        return ""
    return value.strip()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--parties", required=True, type=Path, help="Official Manifesto Project party-list CSV")
    parser.add_argument("--documents", required=True, type=Path, help="Official Manifesto Project coded-document-list CSV")
    parser.add_argument("--partyfacts-external", required=True, type=Path, help="Party Facts external-parties CSV")
    parser.add_argument("--country-map", required=True, type=Path, help="Reviewed Manifesto-country crosswalk CSV")
    parser.add_argument("--output", required=True, type=Path, help="Output data directory")
    parser.add_argument("--as-of", type=date.fromisoformat, default=date.today(), help="Research date (YYYY-MM-DD)")
    args = parser.parse_args()

    start_year = args.as_of.year - 100
    party_rows = read_csv(args.parties)
    document_rows = read_csv(args.documents)
    external_rows = read_csv(args.partyfacts_external)
    country_rows = read_csv(args.country_map)
    country_by_id = {clean(row.get("manifesto_country_code")): row for row in country_rows}

    partyfacts_ids_by_manifesto_id: dict[str, set[str]] = defaultdict(set)
    for row in external_rows:
        if clean(row.get("dataset_key")) != "manifesto":
            continue
        manifesto_id = clean(row.get("dataset_party_id"))
        partyfacts_id = clean(row.get("partyfacts_id"))
        if not manifesto_id or not partyfacts_id:
            continue
        partyfacts_ids_by_manifesto_id[manifesto_id].add(partyfacts_id)

    documents_by_party: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in document_rows:
        manifesto_id = clean(row.get("party"))
        date_value = integer(row.get("date"))
        if not manifesto_id or date_value is None:
            continue
        year = date_value // 100
        if start_year <= year <= args.as_of.year:
            documents_by_party[manifesto_id].append(row)

    party_register: list[dict[str, object]] = []
    for row in party_rows:
        manifesto_id = clean(row.get("party"))
        year_min = integer(row.get("year_min"))
        year_max = integer(row.get("year_max"))
        documents = documents_by_party.get(manifesto_id, [])
        if not manifesto_id or year_min is None or year_max is None:
            continue
        if year_min > args.as_of.year or year_max < start_year or not documents:
            continue
        manifesto_country_id = clean(row.get("country"))
        country = country_by_id.get(manifesto_country_id)
        if country is None:
            raise ValueError(f"No reviewed country mapping for Manifesto code {manifesto_country_id!r}")
        years = [int(clean(document.get("date"))) // 100 for document in documents]
        pf_ids = sorted(partyfacts_ids_by_manifesto_id.get(manifesto_id, set()))
        partyfacts_id = pf_ids[0] if len(pf_ids) == 1 else ""
        party_register.append(
            {
                "manifesto_party_id": manifesto_id,
                "manifesto_country_code": manifesto_country_id,
                "manifesto_country_name": clean(row.get("countryname")),
                "country_code": clean(country.get("country_code")),
                "country_mapping_type": clean(country.get("mapping_type")),
                "country_mapping_note": clean(country.get("mapping_note")),
                "partyfacts_id": partyfacts_id,
                "partyfacts_ids": ";".join(pf_ids),
                "partyfacts_link_status": "linked" if len(pf_ids) == 1 else ("multiple_links" if pf_ids else "not_linked"),
                "party_abbreviation": clean(row.get("abbrev")),
                "party_name_original": clean(row.get("name")),
                "party_name_english": clean(row.get("name_english")),
                "manifesto_year_min": year_min,
                "manifesto_year_max": year_max,
                "is_alliance": clean(row.get("is_alliance")),
                "max_pervote": clean(row.get("max_pervote")),
                "max_presvote": clean(row.get("max_presvote")),
                "year_max_pervote": clean(row.get("year_max_pervote")),
                "year_max_presvote": clean(row.get("year_max_presvote")),
                "documents_in_window": len(documents),
                "first_document_year_in_window": min(years),
                "last_document_year_in_window": max(years),
                "dataset_version": DATASET_VERSION,
                "source_url": PARTY_LIST_URL,
                "research_window_start_year": start_year,
                "research_as_of": args.as_of.isoformat(),
            }
        )

    included_manifesto_ids = {str(row["manifesto_party_id"]) for row in party_register}
    party_metadata_by_id = {str(row["manifesto_party_id"]): row for row in party_register}
    document_register: list[dict[str, object]] = []
    for row in document_rows:
        manifesto_id = clean(row.get("party"))
        date_value = integer(row.get("date"))
        if manifesto_id not in included_manifesto_ids or date_value is None or not start_year <= date_value // 100 <= args.as_of.year:
            continue
        party_metadata = party_metadata_by_id[manifesto_id]
        document_register.append(
            {
                "manifesto_party_id": manifesto_id,
                "manifesto_country_code": clean(row.get("country")),
                "manifesto_country_name": clean(row.get("countryname")),
                "country_code": party_metadata["country_code"],
                "partyfacts_ids": ";".join(sorted(partyfacts_ids_by_manifesto_id.get(manifesto_id, set()))),
                "party_name_english": clean(row.get("partyname")),
                "document_date_yyyymm": date_value,
                "document_year": date_value // 100,
                "document_title": clean(row.get("title")),
                "dataset_version": DATASET_VERSION,
                "source_url": DOCUMENT_LIST_URL,
                "research_window_start_year": start_year,
                "research_as_of": args.as_of.isoformat(),
            }
        )

    party_register.sort(key=lambda row: (str(row["country_code"]), str(row["party_name_english"]), str(row["manifesto_party_id"])))
    document_register.sort(key=lambda row: (str(row["country_code"]), str(row["document_date_yyyymm"]), str(row["manifesto_party_id"])))
    write_csv(args.output / "manifesto-party-register.csv", party_register)
    write_csv(args.output / "manifesto-document-register.csv", document_register)

    party_ids_with_crosswalk = {str(row["manifesto_party_id"]) for row in party_register if row["partyfacts_ids"]}
    print(json.dumps({
        "as_of": args.as_of.isoformat(),
        "window_start_year": start_year,
        "window_end_year": args.as_of.year,
        "manifesto_parties": len(party_register),
        "coded_documents": len(document_register),
        "manifesto_source_country_codes": len({str(row["manifesto_country_code"]) for row in party_register}),
        "coverage_country_units": len({str(row["country_code"]) for row in party_register}),
        "parties_with_partyfacts_crosswalk": len(party_ids_with_crosswalk),
        "parties_without_partyfacts_crosswalk": len(party_register) - len(party_ids_with_crosswalk),
        "partyfacts_manifesto_ids_not_in_register": len(set(partyfacts_ids_by_manifesto_id) - included_manifesto_ids),
        "note": "The public registers provide party and document metadata, not the login-restricted coded policy values.",
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
