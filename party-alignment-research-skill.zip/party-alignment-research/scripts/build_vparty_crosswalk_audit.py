#!/usr/bin/env python3
"""Audit V-Party Party Facts IDs against Party Facts' explicit V-Party crosswalk."""

from __future__ import annotations

import argparse
import csv
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def normalize(value: str | None) -> str:
    value = unicodedata.normalize("NFKD", value or "").encode("ascii", "ignore").decode().casefold()
    return re.sub(r"[^a-z0-9]+", "", value)


def names_match(source_rows: list[dict[str, str]], target: dict[str, str]) -> bool:
    target_names = {normalize(target.get(field)) for field in ("name_english", "name", "name_short", "name_original") if target.get(field)}
    target_names.discard("")
    for row in source_rows:
        source_names = {normalize(row.get(field)) for field in ("v2paenname", "v2paorname", "v2pashname") if row.get(field)}
        if source_names & target_names:
            return True
    return False


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--vparty-measures", required=True, type=Path)
    parser.add_argument("--partyfacts-external", required=True, type=Path)
    parser.add_argument("--partyfacts-core", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    measures = read_csv(args.vparty_measures)
    external = read_csv(args.partyfacts_external)
    core = read_csv(args.partyfacts_core)
    measures_by_id: dict[str, list[dict[str, str]]] = defaultdict(list)
    external_by_id: dict[str, list[dict[str, str]]] = defaultdict(list)
    core_by_id = {row.get("partyfacts_id", "").strip(): row for row in core}
    for row in measures:
        vparty_id = (row.get("v2paid") or "").strip()
        if vparty_id:
            measures_by_id[vparty_id].append(row)
    for row in external:
        if row.get("dataset_key") == "vparty" and row.get("dataset_party_id"):
            external_by_id[row["dataset_party_id"].strip()].append(row)

    columns = [
        "v2paid", "country_text_id", "vparty_name_english", "vparty_name_original", "vparty_short_name",
        "observed_years", "measure_rows", "raw_pf_party_ids", "external_pf_party_ids",
        "external_name_match", "external_country_match", "core_name_match", "core_country_match",
        "crosswalk_status", "candidate_join_partyfacts_id", "needs_review",
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    status_counts: Counter[str] = Counter()
    with args.output.open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=columns)
        writer.writeheader()
        for vparty_id in sorted(measures_by_id, key=lambda value: (not value.isdigit(), int(value) if value.isdigit() else value)):
            source_rows = measures_by_id[vparty_id]
            country_codes = sorted({row.get("country_text_id", "").strip() for row in source_rows if row.get("country_text_id", "").strip()})
            names = {field: sorted({row.get(source_field, "").strip() for row in source_rows if row.get(source_field, "").strip()}) for field, source_field in (
                ("english", "v2paenname"), ("original", "v2paorname"), ("short", "v2pashname"),
            )}
            raw_ids = sorted({row.get("pf_party_id", "").strip() for row in source_rows if row.get("pf_party_id", "").strip()})
            ext_rows = external_by_id.get(vparty_id, [])
            ext_ids = sorted({row.get("partyfacts_id", "").strip() for row in ext_rows if row.get("partyfacts_id", "").strip()})
            target_ext = ext_rows[0] if ext_rows else {}
            target_raw = core_by_id.get(raw_ids[0], {}) if len(raw_ids) == 1 else {}
            source_name_match = names_match(source_rows, target_ext) if target_ext else False
            ext_country_match = bool(target_ext and len(country_codes) == 1 and country_codes[0] == (target_ext.get("country") or "").strip())
            raw_name_match = names_match(source_rows, target_raw) if target_raw else False
            raw_country_match = bool(target_raw and len(country_codes) == 1 and country_codes[0] == (target_raw.get("country") or "").strip())

            resolved = ""
            if len(ext_ids) > 1:
                status = "multiple_partyfacts_external_links_needs_review"
            elif len(ext_ids) == 1 and source_name_match and ext_country_match:
                resolved = ext_ids[0]
                status = "external_link_confirmed_by_name_and_country"
                if raw_ids and raw_ids != ext_ids:
                    status = "external_link_corrects_conflicting_raw_id"
            elif len(ext_ids) == 1:
                status = "external_link_conflicts_with_name_or_country_needs_review"
            elif len(raw_ids) == 1 and raw_name_match and raw_country_match:
                resolved = raw_ids[0]
                status = "raw_id_matches_core_name_and_country_external_row_missing"
            elif len(raw_ids) == 1:
                status = "raw_id_only_needs_review"
            elif raw_ids:
                status = "multiple_raw_ids_needs_review"
            else:
                status = "no_partyfacts_link_available"
            status_counts[status] += 1
            years = sorted({int(float(row["year"])) for row in source_rows if row.get("year")})
            writer.writerow({
                "v2paid": vparty_id,
                "country_text_id": ";".join(country_codes),
                "vparty_name_english": ";".join(names["english"]),
                "vparty_name_original": ";".join(names["original"]),
                "vparty_short_name": ";".join(names["short"]),
                "observed_years": f"{min(years)}-{max(years)}" if years else "",
                "measure_rows": len(source_rows),
                "raw_pf_party_ids": ";".join(raw_ids),
                "external_pf_party_ids": ";".join(ext_ids),
                "external_name_match": str(source_name_match).lower(),
                "external_country_match": str(ext_country_match).lower(),
                "core_name_match": str(raw_name_match).lower(),
                "core_country_match": str(raw_country_match).lower(),
                "crosswalk_status": status,
                "candidate_join_partyfacts_id": resolved,
                "needs_review": str(status not in {"external_link_confirmed_by_name_and_country", "external_link_corrects_conflicting_raw_id", "raw_id_matches_core_name_and_country_external_row_missing"}).lower(),
            })
    print({"vparty_ids": len(measures_by_id), "status_counts": dict(sorted(status_counts.items())), "output": str(args.output)})


if __name__ == "__main__":
    main()
