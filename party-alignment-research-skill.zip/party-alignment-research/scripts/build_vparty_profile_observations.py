#!/usr/bin/env python3
"""Materialize partial, dated profile records from V-Party evidence."""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import re
from collections import defaultdict
from datetime import date
from pathlib import Path


DATA_URL = "https://github.com/vdeminstitute/vdemdata"
CODEBOOK_URL = "https://v-dem.net/documents/6/vparty_codebook_v2.pdf"
POLICY_GAPS = [
    "No comprehensive evidence was added for tax details, public services, labor beyond the selected indicator, property, environment, technology, security, military affairs, or international relations.",
    "Current party documents and recent legislative or governing records were not cross-checked for this observation.",
]
CULTURE_GAPS = [
    "This observation does not establish internal democracy, coalition practices, actual treatment of dissent, governing conduct, or member and supporter behavior.",
    "Leadership, party continuity, and any alliance status require identity review against primary sources.",
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def year_value(value: str) -> int | None:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def int_value(value: str) -> int | None:
    if not value:
        return None
    try:
        return int(float(value))
    except ValueError:
        return None


def confidence_for(point_use: str) -> str:
    if point_use == "eligible_with_uncertainty_and_context":
        return "medium"
    return "low"


def limitation_for(row: dict[str, str], dictionary: dict[str, dict[str, str]]) -> str:
    limits = [dictionary[row["indicator_code"]]["limitations"]]
    point_use = row["point_estimate_use"]
    if point_use == "do_not_interpret_point_estimate_three_or_fewer_ratings":
        limits.append("The codebook strongly advises against interpreting point estimates based on three or fewer expert ratings.")
    elif point_use == "below_five_coder_target_use_with_caution":
        limits.append("This observation has fewer than the preferred five expert ratings and requires caution.")
    elif point_use == "derived_index_coder_count_unavailable_check_components":
        limits.append("This derived index has no indicator-specific coder count in the extract. Check component measures, coder counts, and uncertainty.")
    limits.append("This is a pre-election expert-coded observation, not a complete party profile or evidence of governing conduct.")
    return " ".join(limits)


def make_evidence(row: dict[str, str], dictionary: dict[str, dict[str, str]], year: int, accessed_at: str) -> dict[str, object]:
    definition = dictionary[row["indicator_code"]]
    low = float(row["uncertainty_low"]) if row["uncertainty_low"] else None
    high = float(row["uncertainty_high"]) if row["uncertainty_high"] else None
    evidence = {
        "claim": f"V-Party v2 estimate: {row['estimate']} on the source scale {definition['scale_min']}–{definition['scale_max']}. {definition['interpretation']}",
        "topic": definition["topic"],
        "status": "documented",
        "evidence_type": "expert_dataset",
        "valid_from": year,
        "valid_to": year,
        "source_date": None,
        "source_title": "V-Party v2 party-election observation, V-Dem vdemdata 16.0",
        "url": DATA_URL,
        "accessed_at": accessed_at,
        "confidence": confidence_for(row["point_estimate_use"]),
        "limitations": limitation_for(row, dictionary),
        "contrary_evidence": [],
        "indicator_code": row["indicator_code"],
        "estimate": float(row["estimate"]),
        "scale_min": float(definition["scale_min"]),
        "scale_max": float(definition["scale_max"]),
        "scale_type": definition["scale_type"],
        "uncertainty_low": low,
        "uncertainty_high": high,
        "uncertainty_interval": definition["interval_definition"],
        "coder_count": int_value(row["coder_count"]),
        "point_estimate_use": row["point_estimate_use"],
        "codebook_url": CODEBOOK_URL,
        "dataset_release": "V-Party v2; vdemdata 16.0 (2026)",
    }
    return evidence


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", required=True, type=Path)
    parser.add_argument("--dictionary", required=True, type=Path)
    parser.add_argument("--partyfacts-core", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--as-of", type=date.fromisoformat, default=date.today())
    args = parser.parse_args()

    dictionary_rows = read_csv(args.dictionary)
    dictionary = {row["indicator_code"]: row for row in dictionary_rows}
    partyfacts_core = {row["partyfacts_id"]: row for row in read_csv(args.partyfacts_core) if row.get("partyfacts_id")}
    groups: dict[tuple[str, str, str], list[dict[str, str]]] = defaultdict(list)
    for row in read_csv(args.evidence):
        source_date = row.get("election_date", "")
        key_date = source_date or str(year_value(row["year"]))
        groups[(row["v2paid"], row["country_text_id"], key_date)].append(row)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    policy_count = 0
    culture_count = 0
    opener = gzip.open if args.output.name.endswith(".gz") else Path.open
    records_written = 0
    with opener(args.output, "wt", encoding="utf-8", newline="") as output:
        for (vparty_id, country_code, observation_date), values in sorted(groups.items()):
            year = year_value(values[0]["year"])
            if year is None:
                continue
            values.sort(key=lambda row: row["indicator_code"])
            policy = [make_evidence(row, dictionary, year, args.as_of.isoformat()) for row in values if dictionary[row["indicator_code"]]["dimension"] == "policy"]
            culture = [make_evidence(row, dictionary, year, args.as_of.isoformat()) for row in values if dictionary[row["indicator_code"]]["dimension"] == "political_culture"]
            policy_count += len(policy)
            culture_count += len(culture)
            topics_policy = sorted({dictionary[row["indicator_code"]]["topic"] for row in values if dictionary[row["indicator_code"]]["dimension"] == "policy"})
            topics_culture = sorted({dictionary[row["indicator_code"]]["topic"] for row in values if dictionary[row["indicator_code"]]["dimension"] == "political_culture"})
            base = values[0]
            country_name = base["country_name"] or base["histname"] or country_code
            partyfacts_id = int_value(base.get("partyfacts_id", ""))
            partyfacts_record = partyfacts_core.get(str(partyfacts_id), {}) if partyfacts_id is not None else {}
            first_active = year_value(partyfacts_record.get("year_first", ""))
            last_active = year_value(partyfacts_record.get("year_last", ""))
            alliance_code = int_value(base.get("party_alliance_code", ""))
            alliance_type = "alliance" if alliance_code == 2 or base["party_name_english"].casefold().startswith("alliance:") else ("party" if alliance_code in (0, 1) else "uncertain")
            raw_pf_id = base.get("raw_pf_party_id", "")
            crosswalk_status = base.get("partyfacts_crosswalk_status", "audit_row_missing")
            crosswalk_needs_review = base.get("partyfacts_crosswalk_needs_review", "true") == "true"
            source_profile_key = observation_date if observation_date else str(year)
            safe_key = re.sub(r"[^A-Za-z0-9._-]+", "-", f"{country_code}-{vparty_id}-{source_profile_key}").strip("-")
            profile = {
                "profile_id": f"vparty-{safe_key}",
                "partyfacts_id": partyfacts_id,
                "country_unit": {
                    "code": country_code,
                    "name": country_name,
                    "status_note": "Country code and label follow the V-Party source. Review historical borders and political-unit status before cross-country comparison.",
                },
                "party_identity": {
                    "name_english": base["party_name_english"],
                    "name_original": base["party_name_original"],
                    "name_short": base["party_name_short"],
                    "aliases": [partyfacts_record["name_other"]] if partyfacts_record.get("name_other") else [],
                    "predecessors": [],
                    "successors": [],
                    "party_or_alliance": alliance_type,
                    "identity_notes": (
                        f"V-Party party ID {vparty_id}. Raw V-Party pf_party_id={raw_pf_id or 'missing'}. "
                        f"Party Facts external crosswalk status: {crosswalk_status}. "
                        + ("The identity link needs review, so this profile does not assign a Party Facts ID. " if crosswalk_needs_review else f"Resolved Party Facts ID: {partyfacts_id or 'unavailable'}. ")
                        + "Party continuity and predecessor/successor relationships have not been researched."
                    ),
                    "vparty_id": int_value(vparty_id),
                    "operating_dates": {
                        "start_year": first_active,
                        "end_year": last_active,
                        "basis": "partyfacts_record" if partyfacts_record else "unknown",
                        "note": "Party Facts recorded years; dates and current party status have not been independently checked." if partyfacts_record else "No reviewed operating-date source is attached to this draft.",
                    },
                    "current_status": "unknown",
                    "current_status_as_of": args.as_of.isoformat(),
                    "name_other_raw": partyfacts_record.get("name_other", ""),
                },
                "period": {
                    "label": f"V-Party election observation, {year}",
                    "valid_from": year,
                    "valid_to": year,
                },
                "policy_summary": (
                    "Partial structured pre-election evidence covers " + ", ".join(topics_policy) + ". "
                    "It does not constitute a complete policy profile or describe governing conduct."
                    if topics_policy else "No selected V-Party policy indicator is available for this observation."
                ),
                "political_culture_summary": (
                    "Partial structured pre-election evidence covers " + ", ".join(topics_culture) + ". "
                    "It does not constitute a complete account of party organization or behavior."
                    if topics_culture else "No selected V-Party political-culture indicator is available for this observation."
                ),
                "policy_evidence": policy,
                "political_culture_evidence": culture,
                "confidence": "low",
                "review_status": "draft",
                "verified_at": None,
                "known_gaps": sorted(set(POLICY_GAPS + CULTURE_GAPS)),
                "source_record": {
                    "vparty_id": int_value(vparty_id),
                    "raw_pf_party_id": int_value(raw_pf_id),
                    "partyfacts_id": partyfacts_id,
                    "partyfacts_crosswalk_status": crosswalk_status,
                    "partyfacts_crosswalk_needs_review": crosswalk_needs_review,
                    "country_text_id": country_code,
                    "year": year,
                    "election_date": base["election_date"] or None,
                    "party_alliance_code": alliance_code,
                    "pre_electoral_alliance_name": base.get("pre_electoral_alliance_name", ""),
                    "dataset_release": "V-Party v2; V-Dem vdemdata 16.0 (2026)",
                    "source_snapshot_date": args.as_of.isoformat(),
                    "selected_indicator_count": len(values),
                    "profile_basis": "selected expert-coded indicators only; narrative research and cross-checks remain incomplete",
                },
            }
            output.write(json.dumps(profile, ensure_ascii=False, separators=(",", ":")) + "\n")
            records_written += 1

    print(json.dumps({
        "draft_profile_records": records_written,
        "policy_evidence_items": policy_count,
        "political_culture_evidence_items": culture_count,
        "output": str(args.output),
        "review_status": "draft",
    }))


if __name__ == "__main__":
    main()
