# Party profile schema

Store one profile per party and meaningful historical period. Use the Party Facts identifier where available, but retain source-specific identifiers because merges and alliances can make identity links uncertain.

## Identity

Record the party's English and original names, common abbreviations, country or political-unit code, Party Facts ID, source IDs, organization start and end dates, status, aliases, predecessor and successor links, factions, and whether the record represents a party, coalition, or electoral alliance. Add a note when a country boundary or party identity is disputed.

## Policy

For each topic, record the party's stated position, observed policy or governing record, date range, salience, evidence status, and disagreement among sources. Cover economic organization, taxation, public services and welfare, labor, property, civil liberties, equal and minority rights, migration, religion and government, environment, technology and digital policy, security, military, and international relations. Add locally important topics when evidence supports them.

Keep positions distinct from priorities. For example, note both what a party proposes on climate policy and whether it makes climate a major campaign issue. Do not infer a position from one policy vote without context.

## Political culture

Describe leadership concentration, leader selection, candidate selection, internal participation, treatment of dissent, policy disagreement, coalition and compromise practices, respect for political competition and institutions, public rhetoric, supporter and member organization, interest-group ties, and documented tolerance or use of political violence. Cite specific practices and dates. Distinguish a party's rhetoric from the conduct of its members, officials, or supporters.

## Evidence record

Each evidence item should include:

```json
{
  "claim": "Short, specific claim",
  "dimension": "policy or political_culture",
  "topic": "Relevant topic",
  "status": "documented | mixed | not_stated | unknown",
  "evidence_type": "official_position | campaign | legislative | governing | organizational | independent_assessment",
  "valid_from": "YYYY or null",
  "valid_to": "YYYY or null",
  "source_date": "YYYY-MM-DD or null",
  "source_title": "Title",
  "url": "https://...",
  "accessed_at": "YYYY-MM-DD",
  "confidence": "high | medium | low | contested",
  "limitations": "Measurement or source caveat",
  "contrary_evidence": []
}
```

The profile record also needs `profile_id`, `partyfacts_id`, `country_unit`, `period_label`, `verified_at`, `review_status`, and `identity_notes`. Keep raw dataset scores with their original scale and codebook. Add a plain-language summary only after checking it against the evidence records.

Use `unknown` when research has not established a position. Use `not_stated` only when you checked the relevant materials and found no position. Use `mixed` when credible evidence documents real internal, temporal, or statement-versus-practice differences. Never convert missing evidence to a midpoint or a guessed ideological label.
