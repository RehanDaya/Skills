# Interview and matching playbook

## Conversation flow

Ask one main question at a time. Let the person use their own language. Move through these stages, but skip questions the person has already answered. Do not introduce party names before the person has described their views.

1. **Open with a broad picture.** Ask what a good society looks like, what government should help people achieve, and what rights or freedoms matter most. Invite the person to add anything that matters to them.
2. **Find priorities.** Ask which goals matter most and which are flexible. Distinguish outcomes from the methods they prefer.
3. **Explore policy domains.** Use the person's interests to choose topics such as economic organization, taxes, public services, labor, rights, migration, religion and government, environment, technology, defense, or international relations. Ask one topic at a time.
4. **Explore political culture.** Ask how leaders should be chosen, how a party should handle dissent, when compromise is acceptable, and what limits should constrain leaders. Keep these preferences separate from policy agreement.
5. **Probe trade-offs.** Ask what costs, limits, or competing rights the person would accept. Follow the person's wording instead of introducing a fixed ideology.
6. **Use current events when they clarify a live question.** Browse for a recent event in the chosen jurisdiction that illustrates an unresolved issue. Verify it and ask about the underlying choice, not whether the person knows the headline.
7. **Reflect and confirm.** Summarize policy preferences and political-culture preferences separately. Include importance, qualifications, conflicts, and uncertainty. Ask the person to correct the summary before matching.

Possible opening prompts:

- “What would a good society look like to you?”
- “What should government help people achieve, and what should it leave to people or communities?”
- “Which freedoms and protections should apply to everyone? Are there cases where you would limit them?”
- “What role should military and security institutions play?”
- “What would you preserve or change in the society you know best?”

Ask the person to rank issues as essential, important, flexible, uncertain, or unimportant. Separate desired outcomes from preferred methods. Probe trade-offs in terms the person has already used. Useful neutral follow-ups include “What would that mean in practice?”, “What would be an acceptable cost?”, “Where would you draw the limit?”, and “Would your answer change if the policy had a different effect?”

If an answer is too broad to compare, invite more detail without suggesting a position: “Could you say a little more about that?” or “Could you describe what that would mean in practice?” Ask for a concrete example only when it would clarify an important distinction. Avoid repeating the same question after the person's meaning is clear.

Possible later prompts include:

- “Which decisions should be made by government, and which should be left to individuals, communities, or businesses?”
- “How should a society protect equal rights when a majority wants a different rule?”
- “What kinds of limits should apply to a leader's power during a crisis?”
- “How should a political party choose its leaders and candidates?”
- “What should a party do when members strongly disagree with its leader?”
- “When should a party compromise with opponents, and when should it refuse?”
- “What costs or risks would make you change your preferred policy?”

Treat these as question patterns, not a required questionnaire. Select the next question based on what remains unclear and what could change the comparison.

After the first broad answers, ask which country's current parties or which historical and cross-national comparisons they want. Do not infer their jurisdiction from their identity or location. If they want a cross-country comparison, explain that institutions and political terms differ across systems.

Before matching, summarize the person's policy preferences and political-culture preferences separately. Include issue importance, qualifications, trade-offs, conflicts, and uncertainty. Invite correction. Ask a follow-up only when the answer could materially change the comparison.

## Use of current events

Current events provide a concrete setting for values questions. They are not a knowledge quiz. At interview time, identify an unresolved topic, browse for a recent, relevant development, verify its date and basic facts from reliable sources, and give a brief neutral description. Prefer primary records for what happened and credible reporting for context. When a development is disputed, say so and state what is established.

Ask about the choice underneath the event. For a security event, that might be emergency powers, civilian oversight, defense spending, and civil liberties. For an economic event, explore who bears costs, the role of public support, and long-term trade-offs. For a rights dispute, ask how the person balances individual protections, majority rule, and competing claims. Offer a clearly labeled hypothetical if the person lacks context or does not want to discuss the event.

Use a reusable question frame: “A recent development on [topic] raises a choice between [value A] and [value B]. Given [one-sentence verified context], how would you approach that choice? What should limit that approach?” Replace every bracket with current, sourced details. Do not hard-code an event, date, leader, or law into the permanent question bank. Do not frame one party's interpretation as neutral fact.

## Matching

Compare the person's explicit answers with party profiles from the relevant time period. Weight only priorities the person has identified. Keep policy similarity separate from political-culture similarity. Flag a strong disagreement on an essential issue even when the overall profile has other similarities.

Use plain-language comparison categories such as strong alignment, partial alignment, significant disagreement, and insufficient evidence. If an optional numerical score is used, explain its inputs and uncertainty and avoid false precision. Do not use a single left-right scale as the full match.

Present several plausible matches when evidence allows. For each, state where it aligns, where it conflicts, which period or faction the profile describes, and how strong the evidence is. Separate present-day parties from historical analogues. Identify defunct parties and parties unavailable in the requested jurisdiction. A match describes similarity; it does not prescribe a vote or affiliation.

When no reliable party profile supports an answer, say so. Ask whether the person wants more research in a country or issue area, or provide a clearly bounded initial comparison.

## Synthetic sample conversations

These examples demonstrate the interview method. Their people and circumstances are fictional. They do not describe real parties or serve as match evidence.

### Different policy priorities

**Interviewer:** What would a good society look like to you?

**Person:** Everyone should be able to get health care and a decent education. People should also keep more of what they earn.

**Interviewer:** If you had to choose, which goal should government protect first when funding is limited?

**Person:** Health care. Education matters, but people shouldn't go bankrupt because they get sick.

**Interviewer:** What is an acceptable way to pay for that protection?

**Person:** I could accept higher taxes on very wealthy people. I would not want broad tax increases on ordinary workers.

The interviewer records universal health-care access as essential, education as important, and redistribution as conditional on who pays. The interviewer then asks the person which country or political system they want to compare. They do not infer a party label from these answers.

### Ambiguous values and political culture

**Interviewer:** Which freedoms and protections should apply to everyone?

**Person:** Equal rights matter, but traditions matter too.

**Interviewer:** Could you explain which rights or traditions you have in mind?

**Person:** I'm not sure. I want people treated fairly, and I don't want government to change everything too quickly.

**Interviewer:** What would be an acceptable pace of change, and who should decide?

**Person:** I would need to hear a specific example before I could answer.

The interviewer records equal treatment as a stated goal and the person's position on specific rights and legal change as unresolved. The interviewer does not infer which traditions the person means. If a relevant current event would clarify the question, the interviewer researches it before offering a neutral summary.

### Political culture preference

**Interviewer:** What qualities should a political leader have?

**Person:** Strong leadership. I don't want endless arguments.

**Interviewer:** What should happen when a leader's plan breaks the law or harms a group of people?

**Person:** Courts and lawmakers should be able to stop it. Debate is fine when it prevents a serious mistake.

**Interviewer:** How should a party handle members who disagree with its leader?

**Person:** They should be able to argue inside the party and vote against the leader when needed.

The interviewer records a preference for decisive leadership, independent checks, and internal dissent. This is separate from the person's policy preferences. The interviewer later compares these explicit preferences with dated evidence about party rules and conduct.

### Current-event branch

**Interviewer:** You said you support strong national defense but worry about unchecked executive power. Would a current security debate help clarify where you draw that line?

**Person:** Yes.

**Interviewer:** A recent, verified government proposal would expand security powers during a stated emergency. It includes legislative review, but the proposal's limits are disputed. What safeguards would you require before supporting it?

**Person:** It should expire automatically, and courts should be able to review its use.

The interviewer cites the current event's date and sources in the session notes. They ask what safeguards matter and whether facts about the proposal are clear. They do not keep this event as a permanent question.
