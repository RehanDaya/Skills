---
name: party-alignment-research
description: Research political parties across countries and history, or conduct a neutral, adaptive conversation to compare a person's stated values with party profiles.
---

# Political party research and alignment

Use this skill when someone asks to research political parties, build or update party profiles, or explore which parties most closely reflect their stated views.

The goal is informed comparison. Do not persuade someone to support a party. Describe policy alignment and political-culture alignment separately, explain meaningful disagreements, and preserve uncertainty.

The hand-curated `data/narrative-profile-drafts.jsonl` file contains dated examples, not a complete or verified global party database. Check each record's period, review status, evidence limits, and update date before matching; do not treat a few national examples as country coverage.

For research or database work, follow [the research protocol](references/research-protocol.md) and record new claims in the profile format in [the profile schema](references/profile-schema.md). Start with the candidate directory, country register, V-Party measures and draft profile observations, the V-Party crosswalk audit, and Manifesto party and document registers in `data/`. Review the crosswalk audit before merging V-Party observations with Party Facts identities. Read [the V-Party measure guide](data/vparty-measure-guide.md) and [the Manifesto register guide](data/manifesto-register-guide.md) before interpreting those files. They provide identity, coverage, and selected historical evidence. They do not contain completed party policy or culture assessments. Keep that distinction visible until each narrative profile has evidence.

For an interview, follow [the interview playbook](references/interview-playbook.md). The stand-alone [agent prompt](references/agent-prompt.md) provides a reusable instruction block. Begin with broad values, ask one question at a time, and use neutral follow-ups to clarify priorities, methods, limits, and trade-offs. When useful, browse for a recent event related to an unanswered issue. State its date and source, give brief neutral context, and ask about the underlying choice. Never rely on a fixed headline as a permanent question.

Before matching, ask the person to correct your summary of their views. Compare only profiles from relevant periods. Keep the person's importance ratings and uncertainty attached to each issue. Present several plausible matches when evidence supports them, with concrete agreements, disagreements, profile dates, source quality, and gaps. If the available database cannot justify a match, say what additional research would be needed.

Do not infer preferences from a person's identity or background. Do not treat a party's label, self-description, or a country's culture as a substitute for evidence about that party. Distinguish manifestos and official statements from voting, governing records, organization, and independently documented conduct.

The database is a rolling project. Its current candidate seed covers parties active at any point in 1926–2026. Recalculate the window at each update, update the research date, and follow the expansion and freshness rules in the research protocol.
