# V-Party measure guide

## What the file represents

`vparty-measures.csv` contains party-election observations from the public V-Party dataset bundled in V-Dem's `vdemdata` 16.0 R package (2026). The underlying party dataset is V-Party v2. This seed filters its election years to 1926–2026. The available rows run from 1926 through 2019. Expert-coded values in this extract run from 1965 through 2019.

V-Party codes party positions expressed before an election, including manifestos, press releases, official speeches, and interviews. Its party-election frame usually focuses on parties above 5% of vote share. It also includes some long-standing alliances and one-party regimes. It does not cover every party or measure actual governing results.

The extract contains 10,696 rows, 3,229 V-Party IDs, and 178 country codes. Expert-coded values appear in 6,354 rows for 1,943 V-Party IDs across 170 country codes. Party coverage is not the same as complete political-system coverage.

## Identifiers and links

- `v2paid` is V-Party's own numeric party identifier.
- `pf_party_id` is V-Party's reported Party Facts crosswalk identifier. Treat it as source data that requires consistency checks.
- `country_text_id` is the V-Party country code for that historical observation.
- `year` and `election_date` identify the election-period record.
- `v2paallian` marks whether the coded entity was outside an alliance, a party in an alliance, or an alliance itself.
- `v2panaallian` records the pre-electoral alliance name when available. Preserve these fields because an alliance observation does not always describe an individual party.

Do not assume `v2paid` and `pf_party_id` are interchangeable. Use `v2paid` to find the explicit V-Party row in Party Facts' external-party crosswalk. The current audit found 70 IDs where that crosswalk disagrees with V-Party's reported `pf_party_id`; matching source names and country codes support the external link for those records. Ten other IDs remain unresolved and are kept separate from Party Facts candidates. Read `vparty-crosswalk-audit.csv` before joining. Preserve each source ID, the raw field, resolved link status, party names, dates, country codes, and alliance status. A Party Facts date can also conflict with V-Party's observed election date; `candidate_basis` flags supplemental rows that need identity review.

## Reading estimate fields

- A field ending in `_osp` is an original-scale estimate. Preserve its codebook direction and scale.
- Matching `_osp_codelow` and `_osp_codehigh` fields give the codebook's approximate 70% posterior interval. Wider intervals indicate more uncertainty. The endpoints can be asymmetric around the estimate.
- A field ending in `_nr` records the expert-coder count for that indicator and party-election observation.
- The `v2xpa_antiplural` and `v2xpa_popul` indices run from 0 to 1. Their matching `*_codelow` and `*_codehigh` fields provide uncertainty bounds.
- Do not compare raw values across different indicators as if they share one scale. Do not treat null as a neutral position.

V-Party advises against using expert point estimates supported by three or fewer coder ratings. Prefer five or more ratings when available. The codebook flags special caution for disagreement in political pluralism and pariah-party measures. A coder count does not prove that an estimate is correct.

## Selected indicator meanings

These summaries explain a subset of the included fields. Follow the full codebook for exact wording, categories, and limits.

| Field | Meaning and direction |
| --- | --- |
| `v2xpa_antiplural` | Higher values indicate a weaker commitment to democratic norms before elections. The index combines measures of attacks on opponents, pluralism, minority rights, and political violence. |
| `v2xpa_popul` | Higher values indicate more narrowly defined populist rhetoric, combining anti-elite rhetoric and people-centrism. |
| `v2paanteli_osp` | 0 means leaders never make statements against elites. 4 means anti-elite rhetoric is very important and used whenever possible. |
| `v2papeople_osp` | 0 means leaders never glorify or identify with ordinary people. 4 means they always do so. The codebook describes a claim to represent a unified people. |
| `v2paopresp_osp` | 0 means leaders always use severe personal attacks or demonization against opponents. 4 means they never do. |
| `v2paplur_osp` | 0 means no clear commitment to free and fair multiparty elections and associated freedoms. 4 means full commitment. |
| `v2paminor_osp` | 0 means leaders always argue majority will should prevail even when it violates minority rights. 4 means they never argue that. |
| `v2paviol_osp` | 0 means leaders often encourage violence against domestic political opponents. 4 means they consistently discourage it. |
| `v2paimmig_osp` | 0 strongly opposes immigration. 4 strongly supports immigration. |
| `v2palgbt_osp` | Higher values indicate stronger support for LGBT social equality. Use the exact codebook categories when quoting a score. |
| `v2pawomlab_osp` | Higher values indicate stronger support for equal participation of women in the labor market. |
| `v2pariglef_osp` | 0 is far-left and 6 is far-right on economic ideology. The codebook links this to the party's preferred role of government in the economy. |
| `v2pawelf_osp` | 0 indicates opposition to public welfare. Higher values indicate greater emphasis on universalistic welfare, up to 5 for universal policies. |

The file also includes measures on cultural superiority, religious principles, gender equality, clientelism, party organization, candidate nomination, and internal cohesion. Read their codebook entries before translating them into plain language.

## Using measures in profiles

Use these values as dated, topic-specific evidence. Describe policy alignment and political-culture alignment separately. A score about pre-election rhetoric does not by itself establish party conduct, member behavior, or a person's own values. Pair scores with party documents, legislation, voting records, independent reporting, and historical context.

When summarizing a value, name the election period, original scale, uncertainty bounds when relevant, coder count, dataset version, and source. State what the measure does not establish. Keep disagreements, missing rows, and crosswalk ambiguities visible.

The derived `vparty-profile-evidence.csv` table expands 23 selected measures into one row per non-missing party-election-indicator observation. Join it to `vparty-indicator-dictionary.csv` on `indicator_code` to read each measure's topic, direction, scale, and limitations. The file preserves values with three or fewer coder ratings but flags them `do_not_interpret_point_estimate_three_or_fewer_ratings`. The codebook recommends five or more ratings when possible. Rows with four ratings are flagged for caution. Derived indices do not carry an indicator-specific coder count in this extract, so check their component measures and uncertainty before interpretation.

The `_osp` fields map posterior predictions back to an original ordinal scale. The codebook says these are heuristic values because the intervals between ordinal categories are not necessarily equal. Do not treat them as precise distances or compare values from different indicators as if they shared one scale. Use them as dated evidence alongside the exact response categories and uncertainty bounds.

The selected indicators cover immigration, LGBT social equality, women's labor-market equality, economic left-right position, welfare policy, anti-pluralism, populist rhetoric, anti-elite and people-centric rhetoric, opponent treatment, political pluralism, minority rights, rejection of political violence, cultural-superiority rhetoric, religious justification, women in party leadership, clientelistic campaign benefits, local party offices and activity, social-organization ties, candidate nomination, elite disagreement, and personalization around one leader. They do not cover every policy area or every aspect of political culture.

## Sources

- [V-Party v2 codebook](https://v-dem.net/documents/6/vparty_codebook_v2.pdf)
- [Official V-Dem `vdemdata` package](https://github.com/vdeminstitute/vdemdata)
- [V-Party dataset page](https://www.v-dem.net/data/v-party-dataset/)
