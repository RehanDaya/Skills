# Political party research seed

This dated research seed covers the rolling 100-year window 1926–2026. It combines Party Facts identity records, the UN M49 country-or-area list, V-Party election measures, and public Manifesto Project party and document registers. Source snapshots were retrieved on 2026-10-25.

These files provide candidate identities, structured historical evidence, and a coverage register. They do not constitute completed policy and political-culture profiles. Every `policy_profile_status` and `political_culture_profile_status` value remains `not_researched`. Do not recommend a party until its relevant profile period has been researched and checked.

The narrative-profile status fields indicate whether a full, sourced profile has been researched. They do not indicate whether a party has selected structured observations. The V-Party evidence file contains partial, dated measures for some parties and issues.

## Files

- `party-directory.csv` lists 6,957 candidate records: 6,886 Party Facts core parties whose recorded dates overlap the window, 13 V-Party supplements, and 58 Manifesto Project parties without a Party Facts crosswalk. These are source records, not a verified count of unique parties. `candidate_basis` shows why each row entered the seed. Review unlinked identities before merging them into a party profile.
- `country-coverage.csv` contains 262 coverage units: 248 M49 country-or-area codes, 13 Party Facts-only units, and one V-Party-only historical unit. It is a research register, not a complete list of political systems or parties.
- `country-coverage.csv` also reports V-Party and hand-curated narrative draft counts by source country code when rebuilt with `--vparty-profile-observations` and `--narrative-profile-drafts`. Draft counts remain separate from completed policy and culture profile counters.
- `vparty-measures.csv` contains 10,696 dated party-election rows from the public V-Party data in the V-Dem `vdemdata` 16.0 package. The rows cover 3,229 V-Party IDs and 178 source country codes from 1926 through 2019. Expert-coded measures occur in 6,354 rows, across 1,943 V-Party IDs and 170 country codes, from 1965 through 2019. The directory links measurements to 3,099 candidate records, including 1,907 with at least one expert-coded value. Read `vparty-measure-guide.md` before interpreting the fields.
- `vparty-crosswalk-audit.csv` checks each V-Party ID against Party Facts' explicit V-Party external mapping, names, and country code. It records raw-ID conflicts and keeps unresolved identities separate. The current audit corrects 70 raw-ID conflicts and flags 10 IDs for review.
- `vparty-profile-evidence.csv` is a long-form table of 144,754 non-missing observations across 23 selected policy and political-culture indicators. Each row retains its party and election identifiers, estimate, uncertainty bounds where available, coder count, and an interpretation-use flag. `vparty-indicator-dictionary.csv` defines each indicator, scale, direction, and limitation. These are selected historical observations, not complete party profiles.
- `vparty-profile-observations.jsonl.gz` contains 6,354 draft profile records, one per V-Party party-election observation with selected expert-coded evidence. The records organize 31,511 policy evidence items and 113,243 political-culture evidence items into the profile schema. They distinguish parties from election alliances when V-Party codes that status. These records remain drafts because identity review, primary-source research, independent checks, and broad topic coverage are incomplete.
- `manifesto-party-register.csv` contains 1,428 Manifesto Project parties with document evidence in the 1926–2026 window. It includes English and original names, party and country IDs, observed document years, document counts, and Party Facts crosswalk status.
- `manifesto-document-register.csv` contains 5,320 coded-document references in the window, including election month and title. These records identify document metadata. They do not contain the coded policy values or manifesto text.
- `manifesto-country-crosswalk.csv` maps the 67 Manifesto source country codes to 66 coverage units. It groups Northern Ireland under the United Kingdom for geographic coverage while retaining Manifesto's separate source code. It keeps the German Democratic Republic as a distinct historical unit.
- `research-gaps.csv` records known missing work and the next evidence needed.
- `source-register.csv` records source versions, uses, and limitations.
- `profile-record-template.json` and `profile.schema.json` define the dated narrative profile format.
- `narrative-profile-drafts.jsonl` contains fifteen sourced national-party and coalition drafts across the United States, India, the United Kingdom, France, Brazil, Germany, and South Africa, covering selected evidence from 2020–2026. They remain unreviewed and do not complete country or global profile coverage.
- `m49-country-areas.csv` is the country-or-area roster used for this snapshot.

## Identity and coverage limits

Party Facts links core party identities to observations in other datasets. Its codebook describes an inclusion focus on parties that reached at least 5% of votes in a national election, with additional criteria for some parties. Smaller, regional, banned, underground, and extra-parliamentary groups are not comprehensively listed. A dataset link indicates a crosswalk, not a policy finding.

The Manifesto Project's 2026a codebook reports 1,429 parties, 5,330 programme records, and 67 source countries from 1920 through 2025. The current research-window registers contain 1,428 party records and 5,320 document references. Its party-selection rules focus on seat-winning parties in national elections, with thresholds and exceptions by region and election type. It does not collect regional or extra-parliamentary parties. The 58 register identities without a Party Facts crosswalk remain separate, even when a name looks familiar.

The candidate directory joins the M49 roster with Party Facts country codes and adds V-Party country codes absent from both. A blank M49 region or country match means the unit needs historical-status review. M49 provides statistical country-or-area codes and does not settle political status or borders. The register may still omit historical states, disputed or de facto units, and subnational party systems.

Thirteen V-Party supplemental records preserve observations that lack a reviewed Party Facts link or fall outside the period-filtered directory. The 58 Manifesto supplemental records have no Party Facts crosswalk in the source export. `candidate_basis` flags these cases. The builder resolves V-Party IDs through Party Facts' explicit `vparty` external mapping, then compares names and country codes. The raw V-Party `pf_party_id` field disagrees with that mapping for 70 IDs. The audit applies name-and-country-supported corrections and leaves ten IDs unresolved. Manifesto entries still join through explicit Party Facts IDs.

## Interpretation limits

V-Party offers election-dated expert measures for only some parties and topics. Most expert-coded measurements end in 2019, and the party-election frame does not represent every party or organization. Its values describe specific periods, not current platforms. Missing rows mean unknown coverage, not neutrality or absence of a position.

The Manifesto Project's public party and document registers are metadata. Its coded policy dataset is not included because the official download page requires login. Do not reproduce or distribute its coded values without checking the current terms and access conditions. Even with authorized access, manifesto coding measures campaign texts and substitutes, not governing behavior or political culture.

Neither source fully covers foreign relations, military doctrine, environment, technology, taxation, public services, internal party democracy, or governing results. Research those topics from primary party documents, legislation, votes, budgets, official archives, scholarship, and independent reporting. Treat policy commitments as distinct from governing behavior and political culture.

## Refresh procedure

Download the current core parties, external parties, and countries CSVs from the official [Party Facts download page](https://partyfacts.herokuapp.com/download/). Download the official [V-Dem `vdemdata` package](https://github.com/vdeminstitute/vdemdata) and extract `data/vparty.RData`. Download the Manifesto Project's public [2026a party list](https://manifestoproject.wzb.eu/down/data/2026a/codebooks/parties_MPDataset_MPDS2026a.csv) and [coded-document list](https://manifestoproject.wzb.eu/down/data/2026a/codebooks/documents_MPDataset_MPDS2026a.csv). Export the English country-or-area table from the current [UN M49 list](https://unstats.un.org/unsd/methodology/m49/) with the columns used in `m49-country-areas.csv`. Record each retrieval date and release version.

Extract dated V-Party observations, including party-alliance fields:

```text
python scripts/build_vparty_measures.py --rdata vdemdata/data/vparty.RData --output data/vparty-measures.csv --as-of YYYY-MM-DD
```

Audit V-Party identity links against Party Facts' explicit external mapping before using the measurements:

```text
python scripts/build_vparty_crosswalk_audit.py --measures data/vparty-measures.csv --external external-parties.csv --core core-parties.csv --output data/vparty-crosswalk-audit.csv
```

Build the normalized V-Party profile-evidence table and its indicator dictionary using the audited crosswalk:

```text
python scripts/build_vparty_profile_evidence.py --input data/vparty-measures.csv --crosswalk-audit data/vparty-crosswalk-audit.csv --output data/vparty-profile-evidence.csv --dictionary-output data/vparty-indicator-dictionary.csv
```

Build draft profile records from those observations. The `--partyfacts-core` input adds identity dates and names where the crosswalk is reviewed:

```text
python scripts/build_vparty_profile_observations.py --evidence data/vparty-profile-evidence.csv --dictionary data/vparty-indicator-dictionary.csv --partyfacts-core core-parties.csv --output data/vparty-profile-observations.jsonl.gz --as-of YYYY-MM-DD
```

Build the public Manifesto party and document registers:

```text
python scripts/build_manifesto_register.py --parties parties_MPDataset_MPDS2026a.csv --documents documents_MPDataset_MPDS2026a.csv --partyfacts-external external-parties.csv --country-map data/manifesto-country-crosswalk.csv --output data --as-of YYYY-MM-DD
```

Regenerate the directory and country register with the audited mapping and draft profile counts:

```text
python scripts/build_party_directory.py --core core-parties.csv --external external-parties.csv --countries countries.csv --m49 data/m49-country-areas.csv --vparty-measures data/vparty-measures.csv --vparty-crosswalk-audit data/vparty-crosswalk-audit.csv --manifesto-register data/manifesto-party-register.csv --vparty-profile-observations data/vparty-profile-observations.jsonl.gz --narrative-profile-drafts data/narrative-profile-drafts.jsonl --output data --as-of YYYY-MM-DD
```

The scripts filter by the requested 100-year window and preserve source IDs and measurements. They do not produce narrative profiles or prove exhaustive country coverage. Review every crosswalk row marked for review before merging identities. Update the source register, snapshot counts, and research gaps after each refresh. Re-read each current source codebook and terms before interpreting or distributing new releases.

## Snapshot counts

- Party Facts core records in source snapshot: 7,262.
- Party Facts country or political-unit codes: 224.
- UN M49 country-or-area codes: 248.
- Candidate records in the 1926–2026 directory: 6,957.
- Coverage-register units: 262.
- Manifesto Project source party records: 1,428 across 67 source country codes.
- Manifesto Project coded-document references: 5,320 in 1926–2026.
- Manifesto Project party records without a Party Facts crosswalk: 58.
- V-Party election records: 10,696 for 3,229 V-Party IDs in 178 country codes.
- V-Party expert-coded election rows: 6,354 for 1,943 V-Party IDs in 170 country codes.
- Selected V-Party profile-evidence observations: 144,754 across 23 indicators.
- Draft V-Party profile records: 6,354 across 1,943 V-Party IDs and 1,907 resolved Party Facts IDs.
- Candidate records with any V-Party measurements: 3,099.
- Candidate records with an expert-coded V-Party measurement: 1,907.
- Completed narrative policy profiles: 0. All fifteen U.S., India, UK, France, Brazil, Germany, and South Africa drafts remain unreviewed.
- Completed narrative political-culture profiles: 0.
