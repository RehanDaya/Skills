# Manifesto Project register guide

## What is included

The seed uses two public metadata files from the Manifesto Project's 2026a release:

- `manifesto-party-register.csv` lists party names and identifiers, document-year ranges, vote-share metadata, alliance flags, and Party Facts crosswalk status.
- `manifesto-document-register.csv` lists coded-document titles and election months for the 1926–2026 research window.

This extract contains 1,428 party records and 5,320 document references across 67 Manifesto country codes. The country crosswalk maps those to 66 coverage units because Northern Ireland is grouped under the United Kingdom. The German Democratic Republic remains a separate historical unit.

The official 2026a codebook describes data from 1920–2025, 67 countries, 1,429 parties, and 5,330 programmes. The source party list and coded-document list are public. The official main dataset download requires login, so the policy scores are not in this package.

## Identity and period rules

- `manifesto_party_id` is the Manifesto Project party code. Keep it separate from Party Facts IDs.
- `partyfacts_ids` contains only explicit Party Facts crosswalks from the external-parties file. Do not merge an unlinked record based only on a similar name.
- `partyfacts_link_status` reports `linked`, `multiple_links`, or `not_linked`. Resolve multiple or absent links with evidence and record the decision.
- `manifesto_year_min` and `manifesto_year_max` come from the official party register. They describe Manifesto Project observations, not verified party operating dates.
- `first_document_year_in_window`, `last_document_year_in_window`, and `documents_in_window` summarize the official document list in the requested rolling period.
- `manifesto-country-crosswalk.csv` preserves the original Manifesto country code and records the target political unit. Check its note for border changes and subnational units.

The 58 Manifesto parties without a Party Facts crosswalk remain separate candidate records. Some may duplicate an existing Party Facts party. Check party histories and source identifiers before combining them.

## If the coded dataset becomes available

The codebook states that the content-analysis variables represent shares of quasi-sentences assigned to categories. They measure the emphasis of campaign programmes, not all of a party's beliefs or its governing behavior. The `progtype` field identifies a single-party programme, joint programme, estimate, coalition-derived document, bloc programme, or missing document. Review this field before interpreting a party's data.

Some missing programmes use estimates or substitute documents. The codebook also describes different coding manuals over time and country coverage concentrated in selected national elections. Preserve the release version, party ID, election date, programme type, and manual version. Do not treat an absent category as proof that the party opposes that issue.

The Manifesto Project's `rile` score is one measure of left-right content. It cannot represent all policy domains, political culture, leadership practices, internal democracy, institutional conduct, or political violence. Use the category-level evidence with the codebook and combine it with primary and independent sources.

Do not download around access controls or redistribute coded data without checking the current access terms. The public metadata registers in this seed do not reproduce the gated coded scores.

## Sources

- [Manifesto Project Dataset 2026a](https://manifestoproject.wzb.eu/datasets)
- [Manifesto Project 2026a codebook](https://manifestoproject.wzb.eu/down/data/2026a/codebooks/codebook_MPDataset_MPDS2026a.pdf)
- [Official party list](https://manifestoproject.wzb.eu/down/data/2026a/codebooks/parties_MPDataset_MPDS2026a.csv)
- [Official coded-document list](https://manifestoproject.wzb.eu/down/data/2026a/codebooks/documents_MPDataset_MPDS2026a.csv)
- [Manifesto Project FAQ and coverage rules](https://manifestoproject.wzb.eu/questions)
